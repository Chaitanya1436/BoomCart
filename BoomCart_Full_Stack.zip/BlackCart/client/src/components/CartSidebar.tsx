import { useCart } from "@/context/CartContext";
import { Link, useLocation } from "wouter";
import { X, Plus, Minus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetFooter
} from "@/components/ui/sheet";
import { useAuth } from "@/context/AuthContext";
import LoginModal from "./LoginModal";
import { useState } from "react";

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const CartSidebar = ({ isOpen, onClose }: CartSidebarProps) => {
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const { cartItems, removeFromCart, updateQuantity, getCartTotal, getCartItemCount, isLoading } = useCart();
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  
  const handleCheckout = () => {
    if (!isAuthenticated) {
      setLoginModalOpen(true);
      return;
    }
    
    onClose();
    navigate("/cart");
  };
  
  const subtotal = getCartTotal();
  const shippingCost = subtotal > 0 ? 599 : 0; // $5.99 shipping, free over certain amount
  const tax = Math.round(subtotal * 0.1); // 10% tax
  const total = subtotal + shippingCost + tax;
  
  // Format price in cents to dollars
  const formatPrice = (price: number) => {
    return (price / 100).toFixed(2);
  };
  
  return (
    <>
      <Sheet open={isOpen} onOpenChange={onClose}>
        <SheetContent className="bg-black border-l border-gray-800 w-full sm:max-w-md overflow-hidden flex flex-col p-0">
          <SheetHeader className="p-4 border-b border-gray-800 text-left">
            <div className="flex justify-between items-center">
              <SheetTitle className="text-xl text-white">Your Cart ({getCartItemCount()})</SheetTitle>
              <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-400 hover:text-white">
                <X className="h-5 w-5" />
              </Button>
            </div>
          </SheetHeader>
          
          {isLoading ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-accent"></div>
            </div>
          ) : cartItems.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-6">
              <div className="bg-gray-800 rounded-full p-4 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400"><circle cx="8" cy="21" r="1" /><circle cx="19" cy="21" r="1" /><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" /></svg>
              </div>
              <h3 className="text-lg font-medium mb-2">Your cart is empty</h3>
              <p className="text-gray-400 text-center mb-4">Start adding items to your cart to see them here.</p>
              <Button onClick={onClose} className="bg-accent hover:bg-accent/90">
                Continue Shopping
              </Button>
            </div>
          ) : (
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div 
                    key={item.id} 
                    className="flex bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-4 relative group border border-gray-800 hover:border-gray-700 transition-all duration-300"
                  >
                    {/* Product image */}
                    <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0 bg-gray-800 border border-gray-700">
                      {item.product.imageUrl ? (
                        <img 
                          src={item.product.imageUrl} 
                          alt={item.product.name} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gray-800 text-gray-600">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="9" cy="21" r="1"></circle>
                            <circle cx="20" cy="21" r="1"></circle>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                          </svg>
                        </div>
                      )}
                    </div>
                    
                    {/* Product info */}
                    <div className="ml-4 flex-1">
                      <div className="flex justify-between items-start pr-6">
                        <div>
                          <h3 className="font-medium text-sm line-clamp-1 group-hover:text-accent transition-colors duration-300">
                            {item.product.name}
                          </h3>
                          <p className="text-xs text-gray-400 mt-0.5">
                            {item.product.size && (
                              <span className="inline-flex items-center mr-2">
                                <span className="w-3 h-3 mr-1 rounded-full bg-gray-700 flex items-center justify-center">
                                  <span className="w-1 h-1 bg-gray-500 rounded-full"></span>
                                </span>
                                Size: {item.product.size}
                              </span>
                            )}
                            {item.product.color && (
                              <span className="inline-flex items-center">
                                <span className="w-3 h-3 mr-1 rounded-full bg-gray-700 flex items-center justify-center">
                                  <span className="w-1 h-1 bg-gray-500 rounded-full"></span>
                                </span>
                                Color: {item.product.color}
                              </span>
                            )}
                          </p>
                          
                          {/* Brand badge if available */}
                          {item.product.brand && (
                            <span className="inline-block bg-black/30 text-gray-400 text-[10px] px-1.5 py-0.5 rounded mt-1.5">
                              {item.product.brand}
                            </span>
                          )}
                        </div>
                        
                        {/* Remove button */}
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="absolute top-2 right-2 h-6 w-6 text-gray-500 hover:text-accent hover:bg-transparent p-0 opacity-60 group-hover:opacity-100 transition-opacity"
                          onClick={() => removeFromCart(item.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                      
                      {/* Price and quantity controls */}
                      <div className="flex justify-between items-center mt-3">
                        <div className="text-accent font-bold flex flex-col">
                          <span>${formatPrice(item.product.price)}</span>
                          {item.quantity > 1 && (
                            <span className="text-[10px] text-gray-400 font-normal">
                              ${formatPrice(item.product.price)} each
                            </span>
                          )}
                        </div>
                        
                        <div className="flex items-center bg-black/30 rounded-full p-0.5">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 rounded-full p-0 text-gray-400 hover:text-white hover:bg-black/50"
                            onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                            disabled={item.quantity <= 1}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          
                          <span className="w-8 text-center text-sm font-medium">
                            {item.quantity}
                          </span>
                          
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 rounded-full p-0 text-gray-400 hover:text-white hover:bg-black/50"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      
                      {/* Item total */}
                      <div className="w-full h-px bg-gray-800 my-3"></div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-gray-400">Item total:</span>
                        <span className="font-semibold">
                          ${formatPrice(item.product.price * item.quantity)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
          
          <div className="border-t border-gray-800 bg-gradient-to-b from-gray-900 to-black p-5">
            {/* Coupon/Promo code input - future enhancement */}
            {cartItems.length > 0 && (
              <div className="mb-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gray-400">Have a promo code?</span>
                  <button className="text-xs text-accent">Apply</button>
                </div>
                <div className="flex rounded-lg overflow-hidden">
                  <input 
                    type="text" 
                    placeholder="Enter promo code" 
                    className="flex-1 bg-gray-800 border-0 px-3 py-2 text-sm placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-accent/50"
                  />
                  <button className="bg-accent/20 text-accent hover:bg-accent/30 transition-colors px-3 text-sm font-medium">
                    Apply
                  </button>
                </div>
              </div>
            )}
            
            {/* Order summary */}
            <div className="rounded-xl border border-gray-800 overflow-hidden mb-5">
              <div className="bg-gray-900 p-3 border-b border-gray-800">
                <span className="font-medium text-sm">Order Summary</span>
              </div>
              <div className="p-4 space-y-2.5">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Subtotal:</span>
                  <span>${formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Shipping:</span>
                  <div className="flex items-center">
                    <span>${formatPrice(shippingCost)}</span>
                    {subtotal >= 5000 && (
                      <span className="ml-1.5 bg-green-900/30 text-green-500 text-[10px] px-1.5 py-0.5 rounded-sm">
                        FREE
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Tax (10%):</span>
                  <span>${formatPrice(tax)}</span>
                </div>
                
                <Separator className="bg-gray-800 !my-3" />
                
                <div className="flex justify-between font-bold text-base">
                  <span>Total:</span>
                  <div className="flex flex-col items-end">
                    <span className="text-accent">${formatPrice(total)}</span>
                    <span className="text-[10px] text-gray-500 font-normal">
                      {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Action buttons */}
            <SheetFooter className="flex-col space-y-3 sm:space-y-3">
              <Button 
                className="w-full py-5 bg-accent hover:bg-accent/90 text-white rounded-full font-medium transition-all duration-300 relative overflow-hidden group shadow-lg"
                onClick={handleCheckout}
                disabled={cartItems.length === 0}
              >
                {/* Animated gradient background on hover */}
                <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-orange-600 via-accent to-orange-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-[length:200%_100%] animate-gradient-x"></span>
                
                <span className="relative flex items-center justify-center">
                  <span>Proceed to Checkout</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2 transition-transform group-hover:translate-x-1">
                    <path d="M5 12h14"></path>
                    <path d="m12 5 7 7-7 7"></path>
                  </svg>
                </span>
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full border-gray-700 text-gray-300 hover:bg-gray-800 rounded-full" 
                onClick={onClose}
              >
                Continue Shopping
              </Button>
              
              {/* Payment icons */}
              {cartItems.length > 0 && (
                <div className="flex justify-center pt-2">
                  <div className="flex items-center gap-2 opacity-50">
                    <div className="h-6 w-10 bg-gray-800 rounded"></div>
                    <div className="h-6 w-10 bg-gray-800 rounded"></div>
                    <div className="h-6 w-10 bg-gray-800 rounded"></div>
                    <div className="h-6 w-10 bg-gray-800 rounded"></div>
                  </div>
                </div>
              )}
            </SheetFooter>
          </div>
        </SheetContent>
      </Sheet>
      
      <LoginModal isOpen={loginModalOpen} onClose={() => setLoginModalOpen(false)} />
    </>
  );
};

export default CartSidebar;
