import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import { Star, StarHalf, Plus, Heart, ShoppingCart } from "lucide-react";
import { Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import LoginModal from "./LoginModal";
import { Badge } from "@/components/ui/badge";
import { cn, formatPrice } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  className?: string;
}

const ProductCard = ({ product, className = "" }: ProductCardProps) => {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [isAddingToCart, setIsAddingToCart] = useState(false);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const { isAuthenticated } = useAuth();
  const { addToCart } = useCart();
  const { toast } = useToast();
  
  const { 
    id, 
    name, 
    price, 
    discountPrice, 
    subcategory, 
    rating, 
    reviewCount, 
    isNew,
    imageUrl,
    inStock,
    brand
  } = product;
  
  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isAuthenticated) {
      setLoginModalOpen(true);
      return;
    }
    
    try {
      setIsAddingToCart(true);
      await addToCart(id);
      toast({
        title: "Added to cart",
        description: name,
        duration: 2000,
      });
    } catch (error) {
      console.error("Error adding to cart:", error);
      toast({
        title: "Failed to add to cart",
        variant: "destructive",
        duration: 3000,
      });
    } finally {
      setIsAddingToCart(false);
    }
  };
  
  const handleAddToWishlist = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isAuthenticated) {
      setLoginModalOpen(true);
      return;
    }
    
    try {
      await apiRequest("POST", "/api/wishlist", { productId: id });
      setIsWishlisted(true);
      toast({
        title: "Added to wishlist",
        description: name,
        duration: 2000,
      });
    } catch (error) {
      console.error("Error adding to wishlist:", error);
      toast({
        title: "Failed to add to wishlist",
        variant: "destructive",
        duration: 3000,
      });
    }
  };
  
  // Calculate discount percentage correctly
  const discountPercentage = discountPrice && price < discountPrice 
    ? Math.round(((discountPrice - price) / discountPrice) * 100) 
    : 0;
  
  // Render stars based on rating
  const renderRating = () => {
    const stars = [];
    const fullStars = Math.floor(rating || 0);
    const hasHalfStar = (rating || 0) % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="fill-yellow-400 text-yellow-400 h-4 w-4" />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="fill-yellow-400 text-yellow-400 h-4 w-4" />);
    }
    
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-gray-500 h-4 w-4" />);
    }
    
    return stars;
  };
  
  return (
    <>
      <Link href={`/product/${id}`}>
        <div className={cn(
          "product-card bg-gradient-to-b from-gray-800 to-gray-900 rounded-xl overflow-hidden cursor-pointer border border-gray-700/50 h-full flex flex-col transition-all duration-300 hover:border-accent/30 hover:shadow-lg hover:shadow-accent/5 group",
          className
        )}>
          <div className="relative h-52 overflow-hidden bg-gray-900 flex-shrink-0">
            {/* Product Image */}
            {imageUrl ? (
              <img 
                src={imageUrl} 
                alt={name} 
                className="h-full w-full object-cover transition-all duration-500 group-hover:scale-110"
              />
            ) : (
              <div className="flex items-center justify-center h-full w-full bg-gray-800 text-gray-500">
                <div className="bg-gray-700/50 p-8 rounded-full">
                  <ShoppingCart className="h-10 w-10 opacity-30" />
                </div>
              </div>
            )}
            
            {/* Dark overlay on hover */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            
            {/* Quick shop button that appears on hover */}
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <button 
                className="bg-white text-black font-medium py-2 px-4 rounded-full transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 hover:bg-accent hover:text-white text-sm"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  window.location.href = `/product/${id}`;
                }}
              >
                Quick View
              </button>
            </div>
            
            {/* Status badges */}
            <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
              {brand && (
                <Badge variant="secondary" className="bg-black/60 backdrop-blur-sm text-white border-none px-2.5 py-1">
                  {brand}
                </Badge>
              )}
              
              {!inStock && (
                <Badge variant="outline" className="bg-black/60 backdrop-blur-sm border-gray-500 text-gray-300 px-2.5 py-1">
                  Out of Stock
                </Badge>
              )}
            </div>
            
            <div className="absolute top-3 right-3 flex flex-col gap-1.5 z-10">
              {isNew && (
                <Badge className="bg-green-600 hover:bg-green-700 text-white border-none px-2.5 py-1">
                  NEW
                </Badge>
              )}
              
              {discountPercentage > 0 && (
                <Badge className="bg-accent hover:bg-accent/90 text-white border-none px-2.5 py-1 font-bold">
                  -{discountPercentage}%
                </Badge>
              )}
            </div>
            
            {/* Add to wishlist button */}
            <button 
              className={cn(
                "absolute bottom-3 right-3 p-2.5 bg-black/60 backdrop-blur-sm rounded-full z-10 transition-transform duration-300 group-hover:scale-110",
                isWishlisted ? 'text-accent' : 'text-white hover:text-accent'
              )}
              onClick={handleAddToWishlist}
            >
              <Heart className={cn("h-5 w-5", isWishlisted ? 'fill-accent' : '')} />
            </button>
          </div>
          
          <div className="p-4 flex-grow flex flex-col">
            {/* Product Info */}
            {subcategory && (
              <h3 className="text-xs text-gray-400 tracking-wide uppercase">
                {subcategory}
              </h3>
            )}
            
            <p className="font-medium mt-1 text-sm md:text-base line-clamp-2 group-hover:text-accent transition-colors duration-300">
              {name}
            </p>
            
            {/* Rating */}
            {rating && rating > 0 && (
              <div className="flex items-center mt-2">
                <div className="flex text-sm">
                  {renderRating()}
                </div>
                <span className="text-xs text-gray-400 ml-1">
                  ({reviewCount || 0})
                </span>
              </div>
            )}
            
            {/* Product Price */}
            <div className="flex justify-between items-center mt-auto pt-3">
              <div className="flex flex-col">
                <div className="flex items-center">
                  <span className="text-accent font-bold text-sm md:text-base">
                    {formatPrice(price)}
                  </span>
                  
                  {discountPrice && discountPercentage > 0 && (
                    <span className="text-gray-400 text-xs line-through ml-2">
                      {formatPrice(discountPrice)}
                    </span>
                  )}
                </div>
              </div>
              
              {/* Add to cart button */}
              <button 
                className={cn(
                  "p-2.5 rounded-full text-white transition-all duration-300 shadow-lg",
                  isAddingToCart 
                    ? "bg-gray-600" 
                    : inStock
                      ? "bg-accent hover:bg-accent/90 group-hover:scale-110"
                      : "bg-gray-700 cursor-not-allowed"
                )}
                onClick={handleAddToCart}
                disabled={isAddingToCart || !inStock}
              >
                {isAddingToCart ? (
                  <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  inStock ? <Plus className="h-4 w-4" /> : <ShoppingCart className="h-4 w-4" />
                )}
              </button>
            </div>
          </div>
        </div>
      </Link>
      
      <LoginModal isOpen={loginModalOpen} onClose={() => setLoginModalOpen(false)} />
    </>
  );
};

export default ProductCard;
