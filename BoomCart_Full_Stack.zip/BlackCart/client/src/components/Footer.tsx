import { Link } from "wouter";
import { Facebook, Twitter, Instagram, Mail, Store, Handshake, Flag, Briefcase } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-black border-t border-gray-800 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* About BoomCart */}
          <div>
            <h3 className="text-xl font-bold mb-4">About BoomCart</h3>
            <p className="text-gray-400 mb-4">
              BoomCart is a fully black-themed e-commerce website offering a unique shopping 
              experience with the latest trends in fashion, beauty, and personal care.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          {/* Connect with Us */}
          <div>
            <h3 className="text-xl font-bold mb-4">Connect with Us</h3>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="#" className="hover:text-white transition flex items-center">
                  <Facebook className="h-4 w-4 mr-2" /> Facebook
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition flex items-center">
                  <Twitter className="h-4 w-4 mr-2" /> Twitter
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition flex items-center">
                  <Instagram className="h-4 w-4 mr-2" /> Instagram
                </a>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white transition flex items-center">
                  <Mail className="h-4 w-4 mr-2" /> Contact Us
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Make Money with Us */}
          <div>
            <h3 className="text-xl font-bold mb-4">Make Money with Us</h3>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="#" className="hover:text-white transition flex items-center">
                  <Store className="h-4 w-4 mr-2" /> Sell on BoomCart
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition flex items-center">
                  <Handshake className="h-4 w-4 mr-2" /> Become an Affiliate
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition flex items-center">
                  <Flag className="h-4 w-4 mr-2" /> Advertise Your Products
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition flex items-center">
                  <Briefcase className="h-4 w-4 mr-2" /> Become a Vendor
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} BoomCart. All rights reserved.
          </p>
          <div className="flex space-x-4 text-sm text-gray-500">
            <Link href="/privacy-policy" className="hover:text-white transition">Privacy Policy</Link>
            <Link href="/terms-of-service" className="hover:text-white transition">Terms of Service</Link>
            <Link href="/contact" className="hover:text-white transition">Contact Us</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
