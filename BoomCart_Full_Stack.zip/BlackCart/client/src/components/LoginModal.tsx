import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { FaGoogle } from 'react-icons/fa';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const LoginModal = ({ isOpen, onClose }: LoginModalProps) => {
  const { login } = useAuth();
  
  const handleGoogleLogin = () => {
    login();
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Sign in to BoomCart</DialogTitle>
          <DialogDescription className="text-gray-400">
            Login to access your cart, orders, and wishlist
          </DialogDescription>
        </DialogHeader>
        
        <div className="text-center my-4">
          <Button 
            variant="outline" 
            className="w-full py-6 bg-white text-gray-900 hover:bg-gray-100 border-none"
            onClick={handleGoogleLogin}
          >
            <FaGoogle className="mr-2 h-5 w-5" /> Continue with Google
          </Button>
          
          <div className="relative flex items-center my-6">
            <div className="flex-grow border-t border-gray-700"></div>
            <span className="flex-shrink mx-4 text-gray-400">or</span>
            <div className="flex-grow border-t border-gray-700"></div>
          </div>
          
          <p className="text-gray-400 text-sm">
            This feature is currently unavailable. Please use Google login.
          </p>
        </div>
        
        <DialogFooter className="text-xs text-gray-400 text-center">
          By continuing, you agree to BoomCart's Terms of Service and Privacy Policy.
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default LoginModal;
