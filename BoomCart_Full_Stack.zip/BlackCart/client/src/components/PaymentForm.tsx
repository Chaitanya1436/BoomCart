import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Lock, AlertCircle } from "lucide-react";
import { formatPrice } from "@/lib/utils";

interface PaymentFormProps {
  totalAmount: number;
  onPaymentComplete: (transactionId: string, paymentMethod: string) => void;
  onCancel: () => void;
}

const PaymentForm = ({ totalAmount, onPaymentComplete, onCancel }: PaymentFormProps) => {
  const [paymentMethod, setPaymentMethod] = useState<string>("upi");
  const [transactionId, setTransactionId] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!transactionId.trim()) {
      setFormError("Please enter the transaction ID");
      return;
    }
    
    setFormError(null);
    setIsSubmitting(true);
    
    // Simulate processing
    setTimeout(() => {
      onPaymentComplete(transactionId, paymentMethod);
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
      <CardHeader className="pb-3">
        <CardTitle className="text-2xl font-bold">Complete Payment</CardTitle>
        <CardDescription>
          Total Amount: {formatPrice(totalAmount)}
        </CardDescription>
      </CardHeader>
      
      <Separator className="my-4" />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* UPI Option */}
        <Card 
          className={`cursor-pointer border-2 ${paymentMethod === "upi" ? "border-orange-500" : "border-gray-700"}`} 
          onClick={() => setPaymentMethod("upi")}
        >
          <CardContent className="flex flex-col items-center justify-center h-full p-6">
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-3">
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/UPI-Logo-vector.svg/1200px-UPI-Logo-vector.svg.png" 
                alt="UPI" 
                className="w-6 h-6" 
              />
            </div>
            <p className="font-medium text-center">UPI Payment</p>
          </CardContent>
        </Card>
        
        {/* Credit/Debit Card Option - Locked */}
        <Card className="cursor-not-allowed opacity-50 relative border-gray-700">
          <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-lg">
            <Lock className="w-8 h-8 text-gray-400" />
          </div>
          <CardContent className="flex flex-col items-center justify-center h-full p-6">
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
              </svg>
            </div>
            <p className="font-medium text-center">Card Payment</p>
          </CardContent>
        </Card>
        
        {/* Crypto Option - Locked */}
        <Card className="cursor-not-allowed opacity-50 relative border-gray-700">
          <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-lg">
            <Lock className="w-8 h-8 text-gray-400" />
          </div>
          <CardContent className="flex flex-col items-center justify-center h-full p-6">
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="font-medium text-center">Crypto Payment</p>
          </CardContent>
        </Card>
      </div>
      
      {paymentMethod === "upi" && (
        <Card className="p-4 mb-6">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-bold">UPI Payment Details</CardTitle>
            <CardDescription>
              Scan QR code or pay using UPI ID
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <div className="flex flex-col md:flex-row items-center gap-6">
              {/* QR Code */}
              <div className="w-48 h-48 bg-white p-2 flex items-center justify-center mb-4 md:mb-0">
                <svg
                  className="w-full h-full"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 29 29"
                  shape-rendering="crispEdges"
                >
                  <path fill="#ffffff" d="M0 0h29v29H0z" />
                  <path d="M1 1h7v7h-7zM9 1h2v1h-2zM12 1h1v1h-1zM14 1h1v3h-1zM16 1h1v1h-1zM18 1h1v4h-1zM21 1h7v7h-7zM2 2v5h5V2zM10 2h1v3h-1zM13 2h1v1h-1zM16 2h1v1h-1zM19 2h1v1h-1zM22 2v5h5V2zM3 3h3v3h-3zM11 3h1v2h-1zM15 3h1v1h-1zM17 3h1v2h-1zM23 3h3v3h-3zM15 4h1v3h-1zM19 4h1v1h-1zM10 5h1v2h-1zM12 5h1v1h-1zM16 5h1v1h-1zM19 5h1v2h-1zM9 6h1v2h-1zM12 6h1v2h-1zM16 6h2v1h-2zM1 9h1v1h-1zM3 9h1v2h-1zM5 9h2v1h-2zM8 9h1v2h-1zM10 9h1v1h-1zM13 9h1v3h-1zM15 9h1v1h-1zM19 9h1v1h-1zM21 9h1v1h-1zM23 9h1v1h-1zM25 9h1v1h-1zM27 9h1v6h-1zM1 10h1v1h-1zM4 10h1v1h-1zM6 10h1v3h-1zM9 10h1v1h-1zM11 10h1v2h-1zM14 10h1v1h-1zM16 10h3v1h-3zM24 10h1v1h-1zM2 11h1v1h-1zM4 11h1v2h-1zM7 11h1v1h-1zM10 11h1v1h-1zM14 11h2v1h-2zM17 11h2v1h-2zM20 11h4v1h-4zM25 11h2v1h-2zM1 12h1v2h-1zM5 12h1v1h-1zM9 12h1v1h-1zM12 12h1v1h-1zM15 12h1v1h-1zM17 12h1v1h-1zM19 12h2v1h-2zM22 12h2v1h-2zM25 12h1v1h-1zM3 13h1v1h-1zM5 13h1v3h-1zM7 13h3v1h-3zM12 13h2v2h-2zM15 13h1v1h-1zM17 13h1v1h-1zM20 13h2v1h-2zM23 13h2v1h-2zM26 13h1v1h-1zM1 14h2v2h-2zM4 14h1v1h-1zM7 14h1v3h-1zM9 14h1v1h-1zM11 14h1v1h-1zM14 14h1v1h-1zM16 14h1v3h-1zM18 14h2v1h-2zM21 14h3v1h-3zM25 14h1v1h-1zM3 15h1v1h-1zM6 15h1v1h-1zM9 15h1v1h-1zM11 15h1v3h-1zM15 15h1v1h-1zM17 15h1v1h-1zM19 15h1v2h-1zM21 15h2v1h-2zM24 15h3v1h-3zM1 16h1v1h-1zM3 16h2v1h-2zM8 16h1v1h-1zM10 16h1v1h-1zM14 16h1v1h-1zM17 16h1v1h-1zM20 16h1v3h-1zM22 16h2v1h-2zM25 16h1v1h-1zM27 16h1v1h-1zM1 17h1v3h-1zM3 17h1v1h-1zM6 17h1v1h-1zM8 17h2v1h-2zM12 17h2v1h-2zM15 17h2v2h-2zM18 17h1v1h-1zM21 17h3v1h-3zM25 17h1v4h-1zM27 17h1v1h-1zM3 18h2v1h-2zM6 18h1v2h-1zM9 18h2v1h-2zM12 18h1v1h-1zM14 18h1v1h-1zM17 18h2v1h-2zM22 18h1v1h-1zM26 18h2v1h-2zM2 19h1v1h-1zM4 19h1v1h-1zM7 19h2v1h-2zM10 19h1v1h-1zM12 19h1v1h-1zM17 19h1v1h-1zM19 19h1v1h-1zM21 19h1v1h-1zM24 19h1v1h-1zM27 19h1v1h-1zM2 20h1v1h-1zM4 20h1v2h-1zM8 20h1v1h-1zM13 20h2v1h-2zM16 20h7v1h-7zM24 20h1v1h-1zM27 20h1v1h-1zM1 21h1v7h-1zM3 21h7v1h-7zM11 21h1v1h-1zM13 21h1v1h-1zM15 21h1v1h-1zM17 21h1v1h-1zM19 21h2v1h-2zM22 21h1v1h-1zM26 21h2v1h-2zM2 22h1v5h-1zM8 22h1v5h-1zM10 22h2v1h-2zM13 22h2v1h-2zM16 22h1v1h-1zM18 22h1v1h-1zM21 22h1v1h-1zM23 22h2v1h-2zM26 22h1v1h-1zM3 23h5v1h-5zM10 23h1v1h-1zM12 23h1v1h-1zM14 23h1v1h-1zM16 23h1v1h-1zM19 23h1v2h-1zM21 23h1v2h-1zM24 23h1v1h-1zM27 23h1v2h-1zM3 24h5v1h-5zM9 24h1v4h-1zM11 24h1v2h-1zM14 24h2v1h-2zM17 24h1v2h-1zM23 24h1v2h-1zM25 24h1v1h-1zM3 25h5v1h-5zM10 25h1v1h-1zM12 25h2v1h-2zM15 25h1v1h-1zM18 25h1v2h-1zM20 25h1v1h-1zM22 25h1v2h-1zM24 25h1v1h-1zM26 25h1v3h-1zM12 26h1v1h-1zM14 26h1v1h-1zM16 26h1v2h-1zM19 26h1v1h-1zM21 26h1v1h-1zM24 26h1v1h-1zM10 27h1v1h-1zM12 27h2v1h-2zM17 27h1v1h-1zM19 27h3v1h-3zM27 27h1v1h-1z" fill="#000000" />
                </svg>
              </div>
              
              <div className="space-y-4 flex-1">
                <div>
                  <Label className="text-gray-400">UPI ID</Label>
                  <div className="flex items-center mt-1 gap-2">
                    <Input value="8919255311@ibl" readOnly className="bg-gray-900" />
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText("8919255311@ibl");
                      }}
                    >
                      Copy
                    </Button>
                  </div>
                </div>
                
                <div>
                  <Label className="text-gray-400">Pay to</Label>
                  <Input value="Sariki" readOnly className="bg-gray-900" />
                </div>
                
                <div>
                  <Label className="text-gray-400">Amount</Label>
                  <Input value={formatPrice(totalAmount)} readOnly className="bg-gray-900" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      <form onSubmit={handleSubmit}>
        {formError && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{formError}</AlertDescription>
          </Alert>
        )}
        
        <div className="space-y-6">
          <div>
            <Label htmlFor="transactionId">Enter UPI Transaction ID</Label>
            <Input
              id="transactionId"
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
              placeholder="Enter the 12-digit transaction ID"
              className="mt-1"
              required
            />
            <p className="text-xs text-gray-400 mt-1">
              You can find this in your UPI app payment history
            </p>
          </div>
          
          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="flex-1"
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-orange-500 hover:bg-orange-600"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Processing..." : "Complete Payment"}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default PaymentForm;