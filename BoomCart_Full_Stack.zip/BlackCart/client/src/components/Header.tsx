import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import CartSidebar from "@/components/CartSidebar";
import LoginModal from "@/components/LoginModal";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Heart, ShoppingCart, User } from "lucide-react";

const Header = () => {
  const [cartOpen, setCartOpen] = useState(false);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();
  
  const { isAuthenticated, user } = useAuth();
  const { getCartItemCount } = useCart();
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/category/all?search=${encodeURIComponent(searchQuery)}`);
    }
  };
  
  return (
    <>
      <header className="sticky top-0 z-50 bg-black border-b border-gray-800 shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <Link href="/" className="flex items-center">
              <h1 className="text-2xl md:text-3xl font-bold font-sans text-white">
                <span className="text-accent">Boom</span>Cart
              </h1>
            </Link>
            
            {/* Search Bar (Desktop) */}
            <form 
              className="hidden md:flex items-center flex-1 mx-8 relative"
              onSubmit={handleSearch}
            >
              <Input 
                type="text" 
                placeholder="Search products..." 
                className="w-full px-4 py-2 bg-gray-800 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button 
                type="submit" 
                variant="ghost" 
                className="absolute right-3"
                size="icon"
              >
                <Search className="h-5 w-5 text-gray-400" />
              </Button>
            </form>
            
            {/* Navigation Icons */}
            <div className="flex items-center space-x-4">
              <Link href="/wishlist" className="text-gray-300 hover:text-white transition">
                <Heart className="h-6 w-6" />
              </Link>
              
              <button 
                className="text-gray-300 hover:text-white transition relative"
                onClick={() => setCartOpen(true)}
              >
                <ShoppingCart className="h-6 w-6" />
                <span className="absolute -top-2 -right-2 bg-accent text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {getCartItemCount()}
                </span>
              </button>
              
              <button 
                className="text-gray-300 hover:text-white transition"
                onClick={() => isAuthenticated ? navigate('/orders') : setLoginModalOpen(true)}
              >
                <User className="h-6 w-6" />
              </button>
            </div>
          </div>
          
          {/* Search Bar (Mobile) */}
          <form 
            className="mt-3 md:hidden relative"
            onSubmit={handleSearch}
          >
            <Input 
              type="text" 
              placeholder="Search products..." 
              className="w-full px-4 py-2 bg-gray-800 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button 
              type="submit" 
              variant="ghost" 
              className="absolute right-3 top-2"
              size="icon"
            >
              <Search className="h-5 w-5 text-gray-400" />
            </Button>
          </form>
        </div>
      </header>
      
      {/* Cart Sidebar */}
      <CartSidebar isOpen={cartOpen} onClose={() => setCartOpen(false)} />
      
      {/* Login Modal */}
      <LoginModal isOpen={loginModalOpen} onClose={() => setLoginModalOpen(false)} />
    </>
  );
};

export default Header;
