import { useState, useEffect } from "react";
import { Link } from "wouter";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Category } from "@shared/schema";

const Navigation = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch('/api/categories');
        const data = await response.json();
        setCategories(data);
      } catch (error) {
        console.error('Failed to fetch categories:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchCategories();
  }, []);
  
  if (isLoading) {
    return (
      <nav className="bg-gray-900 py-3 shadow-md">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap gap-4 justify-center text-sm md:text-base">
            <div className="h-10 w-16 bg-gray-800 animate-pulse rounded-md"></div>
            <div className="h-10 w-24 bg-gray-800 animate-pulse rounded-md"></div>
            <div className="h-10 w-32 bg-gray-800 animate-pulse rounded-md"></div>
            <div className="h-10 w-20 bg-gray-800 animate-pulse rounded-md"></div>
            <div className="h-10 w-20 bg-gray-800 animate-pulse rounded-md"></div>
            <div className="h-10 w-20 bg-gray-800 animate-pulse rounded-md"></div>
          </div>
        </div>
      </nav>
    );
  }
  
  return (
    <nav className="bg-gray-900 py-3 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap gap-4 justify-center text-sm md:text-base">
          <Link 
            href="/" 
            className="px-3 py-2 rounded-md text-white font-medium hover:bg-accent transition"
          >
            Home
          </Link>
          
          {categories.map((category) => (
            category.isLocked ? (
              <TooltipProvider key={category.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="px-3 py-2 rounded-md text-gray-400 font-medium cursor-not-allowed">
                      {category.name}
                    </span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{category.message || "No sponsors yet... To sponsor, please mail us."}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ) : (
              <Link
                key={category.id}
                href={`/category/${encodeURIComponent(category.name)}`}
                className="px-3 py-2 rounded-md text-white font-medium hover:bg-accent transition"
              >
                {category.name}
              </Link>
            )
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
