import { useState, useEffect, useCallback, useRef } from "react";
import ProductCard from "./ProductCard";
import { Product } from "@shared/schema";
import { Loader2, ChevronDown, RefreshCcw } from "lucide-react";
import InfiniteScroll from "react-infinite-scroll-component";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";
import { useToast } from "@/hooks/use-toast";

interface ProductGridProps {
  category?: string;
  initialProducts?: Product[];
  isHomePage?: boolean;
  filters?: Record<string, any>;
}

const ProductGrid = ({ 
  category,
  initialProducts,
  isHomePage = false,
  filters = {}
}: ProductGridProps) => {
  const [products, setProducts] = useState<Product[]>(initialProducts || []);
  const [isLoading, setIsLoading] = useState(!initialProducts);
  const [hasMore, setHasMore] = useState(true);
  const [offset, setOffset] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const isMobile = useIsMobile();
  const { toast } = useToast();
  const totalProductsRef = useRef<number>(0);
  const limit = 20;
  
  const fetchProducts = useCallback(async (reset = false) => {
    if (isHomePage && initialProducts) {
      return;
    }
    
    const currentOffset = reset ? 0 : offset;
    
    if (reset) {
      setIsLoading(true);
    }
    
    setError(null);
    
    try {
      // Build query params
      const queryParams = new URLSearchParams();
      if (category && category !== "all") queryParams.append("category", category);
      queryParams.append("limit", limit.toString());
      queryParams.append("offset", currentOffset.toString());
      
      // Add filters
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
          if (Array.isArray(value)) {
            value.forEach(val => queryParams.append(key, val.toString()));
          } else {
            queryParams.append(key, value.toString());
          }
        }
      });
      
      const response = await fetch(`/api/products?${queryParams.toString()}`);
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const data = await response.json();
      totalProductsRef.current = data.total || 0;
      
      if (reset) {
        setProducts(data.products);
        setOffset(limit);
      } else {
        setProducts(prev => [...prev, ...data.products]);
        setOffset(prev => prev + limit);
      }
      
      setHasMore(data.products.length === limit && data.products.length > 0);
      
      // Show a toast when products are loaded after filtering
      if (reset && Object.keys(filters).length > 0 && !isHomePage) {
        toast({
          title: "Products filtered",
          description: `Showing ${data.products.length} of ${data.total} products`,
          duration: 3000,
        });
      }
    } catch (error) {
      console.error("Failed to fetch products:", error);
      setError("Failed to load products. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [category, offset, isHomePage, initialProducts, filters, limit, toast]);
  
  useEffect(() => {
    // Only fetch if no initial products or if filters/category changed
    if (!initialProducts || Object.keys(filters).length > 0) {
      fetchProducts(true);
    }
  }, [category, filters, initialProducts, fetchProducts]);
  
  // Skeleton loader for products
  const ProductSkeleton = () => (
    <div className="bg-gray-800 rounded-lg animate-pulse">
      <div className="h-48 bg-gray-700 rounded-t-lg"></div>
      <div className="p-4">
        <div className="h-4 bg-gray-700 rounded w-1/2 mb-2"></div>
        <div className="h-5 bg-gray-700 rounded w-3/4 mb-3"></div>
        <div className="h-4 bg-gray-700 rounded w-1/4 mb-4"></div>
        <div className="flex justify-between">
          <div className="h-6 bg-gray-700 rounded w-1/4"></div>
          <div className="h-8 w-8 bg-gray-700 rounded-full"></div>
        </div>
      </div>
    </div>
  );
  
  if (isLoading && products.length === 0) {
    // Show skeleton loaders while initial loading
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
        {Array.from({ length: isHomePage ? 4 : 10 }).map((_, i) => (
          <ProductSkeleton key={i} />
        ))}
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="text-center py-12">
        <h3 className="text-xl font-semibold mb-4 text-red-500">{error}</h3>
        <Button 
          variant="outline" 
          onClick={() => fetchProducts(true)}
          className="bg-gray-800 hover:bg-gray-700 text-white"
        >
          <RefreshCcw className="mr-2 h-4 w-4" /> Try Again
        </Button>
      </div>
    );
  }
  
  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <h3 className="text-xl font-semibold mb-2">No products found</h3>
        <p className="text-gray-400">Try adjusting your filters or search terms</p>
        {Object.keys(filters).length > 0 && (
          <Button 
            variant="link" 
            className="text-accent mt-4"
            onClick={() => window.location.search = ''}
          >
            Clear all filters
          </Button>
        )}
      </div>
    );
  }
  
  // For the home page, just render the products without infinite scroll
  if (isHomePage) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    );
  }
  
  // For category pages, use infinite scroll
  return (
    <div>
      {!isLoading && totalProductsRef.current > 0 && (
        <div className="mb-4 text-sm text-gray-400">
          Showing {products.length} of {totalProductsRef.current} products
        </div>
      )}
      
      <InfiniteScroll
        dataLength={products.length}
        next={fetchProducts}
        hasMore={hasMore}
        loader={
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 text-accent animate-spin" />
          </div>
        }
        endMessage={
          <div className="text-center py-8 text-gray-400">
            {products.length > 0 && "You've reached the end of the collection"}
          </div>
        }
        scrollThreshold={0.8}
        className="pb-8"
      >
        <div className={`grid gap-4 sm:gap-6 ${
          isMobile 
            ? 'grid-cols-2' 
            : 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'
        }`}>
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
        
        {hasMore && (
          <div className="flex justify-center mt-8">
            <div className="text-center">
              <div className="bounce mb-2">
                <ChevronDown className="text-accent" />
              </div>
              <p className="text-sm text-gray-400">Scroll for more products</p>
            </div>
          </div>
        )}
      </InfiniteScroll>
    </div>
  );
};

export default ProductGrid;
