import { useAudio } from "../context/AudioContext";
import { useState, useEffect } from "react";
import { Volume2 } from "lucide-react";

const AudioPlayer = () => {
  const { isPlaying, currentTrack } = useAudio();
  const [showPlaying, setShowPlaying] = useState(false);
  
  // Create a pulsing effect to indicate music is playing
  useEffect(() => {
    if (!isPlaying) return;
    
    const interval = setInterval(() => {
      setShowPlaying(show => !show);
    }, 1000);
    
    return () => clearInterval(interval);
  }, [isPlaying]);
  
  if (!isPlaying) return null;
  
  return (
    <div className="fixed bottom-16 right-4 md:bottom-4 md:right-4 z-50">
      <div className={`flex items-center justify-center rounded-full w-10 h-10 bg-black bg-opacity-70 text-orange-500 border border-orange-500 ${showPlaying ? 'scale-110' : 'scale-100'} transition-all duration-500`}>
        <Volume2 className="w-5 h-5" />
      </div>
    </div>
  );
};

export default AudioPlayer;
