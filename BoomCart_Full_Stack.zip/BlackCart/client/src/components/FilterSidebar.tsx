import { useState, useEffect } from "react";
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger,
  SheetFooter
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { FilterIcon, X } from "lucide-react";

interface FilterSidebarProps {
  onFilterChange: (filters: Record<string, any>) => void;
  category?: string;
}

const FilterSidebar = ({ onFilterChange, category }: FilterSidebarProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedRating, setSelectedRating] = useState<number | null>(null);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<string>("");
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  
  // In a real app, these data would come from API
  const brands = ["Nike", "Adidas", "Puma", "Under Armour", "Levi's", "Zara"];
  const colors = ["Black", "White", "Red", "Blue", "Green", "Orange", "Yellow"];
  const sizes = ["XS", "S", "M", "L", "XL", "XXL"];
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const subcategories = ["Men's Fashion", "Women's Fashion", "Skincare", "Hair Care", "Makeup"];
  
  useEffect(() => {
    // If we're in a specific category, add it to active filters
    if (category && category !== "all") {
      setActiveFilters(prev => prev.includes(category) ? prev : [...prev, category]);
    }
  }, [category]);
  
  const handleApplyFilters = () => {
    const filters: Record<string, any> = {};
    const newActiveFilters: string[] = [];
    
    // Add filters
    if (priceRange[0] > 0) {
      filters.minPrice = priceRange[0] * 100; // Convert to cents
      newActiveFilters.push(`Min: $${priceRange[0]}`);
    }
    
    if (priceRange[1] < 1000) {
      filters.maxPrice = priceRange[1] * 100; // Convert to cents
      newActiveFilters.push(`Max: $${priceRange[1]}`);
    }
    
    if (selectedBrands.length > 0) {
      filters.brand = selectedBrands;
      newActiveFilters.push(...selectedBrands);
    }
    
    if (selectedColors.length > 0) {
      filters.color = selectedColors;
      newActiveFilters.push(...selectedColors);
    }
    
    if (selectedSizes.length > 0) {
      filters.size = selectedSizes;
      newActiveFilters.push(...selectedSizes);
    }
    
    if (selectedCategories.length > 0) {
      filters.subcategory = selectedCategories;
      newActiveFilters.push(...selectedCategories);
    }
    
    if (selectedRating !== null) {
      filters.rating = selectedRating;
      newActiveFilters.push(`${selectedRating}★ & Above`);
    }
    
    if (inStockOnly) {
      filters.inStock = true;
      newActiveFilters.push("In Stock");
    }
    
    if (sortBy) {
      filters.sort = sortBy;
    }
    
    setActiveFilters(newActiveFilters);
    onFilterChange(filters);
    setIsOpen(false);
  };
  
  const handleClearFilters = () => {
    setPriceRange([0, 1000]);
    setSelectedBrands([]);
    setSelectedColors([]);
    setSelectedSizes([]);
    setSelectedCategories([]);
    setSelectedRating(null);
    setInStockOnly(false);
    setSortBy("");
    setActiveFilters([]);
    onFilterChange({});
    setIsOpen(false);
  };
  
  // Handle individual checkbox changes
  const handleBrandChange = (brand: string, checked: boolean) => {
    if (checked) {
      setSelectedBrands(prev => [...prev, brand]);
    } else {
      setSelectedBrands(prev => prev.filter(b => b !== brand));
    }
  };
  
  const handleColorChange = (color: string, checked: boolean) => {
    if (checked) {
      setSelectedColors(prev => [...prev, color]);
    } else {
      setSelectedColors(prev => prev.filter(c => c !== color));
    }
  };
  
  const handleSizeChange = (size: string, checked: boolean) => {
    if (checked) {
      setSelectedSizes(prev => [...prev, size]);
    } else {
      setSelectedSizes(prev => prev.filter(s => s !== size));
    }
  };
  
  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories(prev => [...prev, category]);
    } else {
      setSelectedCategories(prev => prev.filter(c => c !== category));
    }
  };
  
  // Remove a single filter
  const removeFilter = (filter: string) => {
    setActiveFilters(prev => prev.filter(f => f !== filter));
    
    // Check which type of filter it is and remove it
    if (selectedBrands.includes(filter)) {
      setSelectedBrands(prev => prev.filter(b => b !== filter));
    } else if (selectedColors.includes(filter)) {
      setSelectedColors(prev => prev.filter(c => c !== filter));
    } else if (selectedSizes.includes(filter)) {
      setSelectedSizes(prev => prev.filter(s => s !== filter));
    } else if (selectedCategories.includes(filter)) {
      setSelectedCategories(prev => prev.filter(c => c !== filter));
    } else if (filter === "In Stock") {
      setInStockOnly(false);
    } else if (filter.includes("★")) {
      setSelectedRating(null);
    } else if (filter.startsWith("Min:")) {
      setPriceRange([0, priceRange[1]]);
    } else if (filter.startsWith("Max:")) {
      setPriceRange([priceRange[0], 1000]);
    }
    
    // Update filters
    handleApplyFilters();
  };
  
  return (
    <div className="mb-6">
      <div className="flex flex-wrap gap-3 mb-4">
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" className="flex gap-2 items-center bg-gray-800 hover:bg-gray-700 text-white border-gray-700">
              <FilterIcon className="h-4 w-4" /> Filters
            </Button>
          </SheetTrigger>
          
          <SheetContent className="bg-gray-800 text-white border-gray-700 overflow-y-auto w-full max-w-md">
            <SheetHeader>
              <SheetTitle className="text-white">Filters</SheetTitle>
            </SheetHeader>
            
            <div className="py-4 space-y-6">
              {/* Price Range */}
              <div>
                <h3 className="font-medium mb-3">Price Range</h3>
                <Slider
                  defaultValue={priceRange}
                  min={0}
                  max={1000}
                  step={10}
                  value={priceRange}
                  onValueChange={setPriceRange}
                  className="mb-2"
                />
                <div className="flex justify-between mt-2">
                  <span className="text-sm text-gray-400">${priceRange[0]}</span>
                  <span className="text-sm text-gray-400">${priceRange[1]}</span>
                </div>
              </div>
              
              {/* Categories - conditionally show if on the "all" category page */}
              {category === "all" && (
                <div>
                  <h3 className="font-medium mb-3">Categories</h3>
                  <div className="space-y-2">
                    {subcategories.map(cat => (
                      <Label key={cat} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`category-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                          checked={selectedCategories.includes(cat)}
                          onCheckedChange={(checked) => handleCategoryChange(cat, checked as boolean)}
                        />
                        <span>{cat}</span>
                      </Label>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Brands */}
              <div>
                <h3 className="font-medium mb-3">Brand</h3>
                <div className="space-y-2">
                  {brands.map(brand => (
                    <Label key={brand} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`brand-${brand.toLowerCase().replace(/\s+/g, '-')}`}
                        checked={selectedBrands.includes(brand)}
                        onCheckedChange={(checked) => handleBrandChange(brand, checked as boolean)}
                      />
                      <span>{brand}</span>
                    </Label>
                  ))}
                </div>
              </div>
              
              {/* Colors */}
              <div>
                <h3 className="font-medium mb-3">Color</h3>
                <div className="flex flex-wrap gap-2">
                  {colors.map(color => (
                    <div 
                      key={color}
                      className={`
                        w-8 h-8 rounded-full cursor-pointer border-2 
                        ${selectedColors.includes(color) ? 'border-accent' : 'border-transparent'}
                      `}
                      style={{ 
                        backgroundColor: color.toLowerCase(), 
                        boxShadow: selectedColors.includes(color) ? '0 0 0 2px rgba(255, 69, 0, 0.3)' : 'none'
                      }}
                      onClick={() => handleColorChange(color, !selectedColors.includes(color))}
                    />
                  ))}
                </div>
              </div>
              
              {/* Sizes */}
              <div>
                <h3 className="font-medium mb-3">Size</h3>
                <div className="flex flex-wrap gap-2">
                  {sizes.map(size => (
                    <div 
                      key={size}
                      className={`
                        w-10 h-10 flex items-center justify-center rounded cursor-pointer
                        ${selectedSizes.includes(size) 
                          ? 'bg-accent text-white' 
                          : 'bg-gray-700 hover:bg-gray-600 text-white'}
                      `}
                      onClick={() => handleSizeChange(size, !selectedSizes.includes(size))}
                    >
                      {size}
                    </div>
                  ))}
                </div>
              </div>
              
              {/* In Stock Only */}
              <div>
                <h3 className="font-medium mb-3">Availability</h3>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="in-stock" 
                    checked={inStockOnly} 
                    onCheckedChange={setInStockOnly} 
                  />
                  <Label htmlFor="in-stock">In Stock Only</Label>
                </div>
              </div>
              
              {/* Rating */}
              <div>
                <h3 className="font-medium mb-3">Rating</h3>
                <RadioGroup value={selectedRating?.toString() || ""} onValueChange={(value) => setSelectedRating(value ? parseInt(value) : null)}>
                  {[5, 4, 3, 2, 1].map(rating => (
                    <div className="flex items-center space-x-2" key={rating}>
                      <RadioGroupItem value={rating.toString()} id={`rating-${rating}`} />
                      <Label htmlFor={`rating-${rating}`} className="flex items-center">
                        {Array(rating).fill(null).map((_, i) => (
                          <span key={i} className="text-yellow-400">★</span>
                        ))}
                        {Array(5 - rating).fill(null).map((_, i) => (
                          <span key={i} className="text-gray-400">★</span>
                        ))}
                        <span className="ml-2 text-sm">&amp; Above</span>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </div>
            
            <SheetFooter className="flex-row space-x-2 pt-4 border-t border-gray-700">
              <Button 
                variant="outline" 
                className="flex-1 border-gray-700 text-gray-300"
                onClick={handleClearFilters}
              >
                Clear All
              </Button>
              <Button 
                variant="default" 
                className="flex-1 bg-accent hover:bg-accent/90"
                onClick={handleApplyFilters}
              >
                Apply Filters
              </Button>
            </SheetFooter>
          </SheetContent>
        </Sheet>
        
        {/* Sort By Dropdown */}
        <Select value={sortBy} onValueChange={(value) => {
          setSortBy(value);
          onFilterChange({ ...Object.fromEntries(Object.entries({})), sort: value });
        }}>
          <SelectTrigger className="bg-gray-800 text-white border-gray-700 w-[180px]">
            <SelectValue placeholder="Sort by: Featured" />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 text-white border-gray-700">
            <SelectItem value="featured">Featured</SelectItem>
            <SelectItem value="price_asc">Price: Low to High</SelectItem>
            <SelectItem value="price_desc">Price: High to Low</SelectItem>
            <SelectItem value="rating">Customer Rating</SelectItem>
            <SelectItem value="newest">Newest First</SelectItem>
          </SelectContent>
        </Select>
        
        {/* View Layout Toggle - these would change the layout in a real app */}
        <div className="ml-auto flex gap-2">
          <Button variant="outline" size="icon" className="bg-gray-800 hover:bg-gray-700 text-white border-gray-700">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="7" height="7" x="3" y="3" rx="1" /><rect width="7" height="7" x="14" y="3" rx="1" /><rect width="7" height="7" x="14" y="14" rx="1" /><rect width="7" height="7" x="3" y="14" rx="1" /></svg>
          </Button>
          <Button variant="outline" size="icon" className="bg-gray-800 hover:bg-gray-700 text-white border-gray-700">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" x2="21" y1="6" y2="6" /><line x1="3" x2="21" y1="12" y2="12" /><line x1="3" x2="21" y1="18" y2="18" /></svg>
          </Button>
        </div>
      </div>
      
      {/* Active Filters Display */}
      {activeFilters.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {activeFilters.map(filter => (
            <Badge 
              key={filter}
              variant="outline" 
              className="bg-gray-800 border-gray-700 text-gray-200 px-3 py-1 flex items-center gap-1"
            >
              {filter}
              <X 
                className="h-3 w-3 cursor-pointer ml-1 hover:text-accent" 
                onClick={() => removeFilter(filter)}
              />
            </Badge>
          ))}
          
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white p-0 h-auto"
            onClick={handleClearFilters}
          >
            Clear All
          </Button>
        </div>
      )}
    </div>
  );
};

export default FilterSidebar;
