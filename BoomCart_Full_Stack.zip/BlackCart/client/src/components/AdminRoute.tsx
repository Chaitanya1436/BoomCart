import { useState, useEffect } from 'react';
import { Route, Redirect } from 'wouter';
import { useAuth } from '@/context/AuthContext';
import { Loader2 } from 'lucide-react';

interface AdminRouteProps {
  path: string;
  component: React.ComponentType<any>;
}

const AdminRoute = ({ path, component: Component }: AdminRouteProps) => {
  const { user, isAuthenticated, isLoading } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [checkingAdmin, setCheckingAdmin] = useState(true);

  useEffect(() => {
    if (!isLoading && isAuthenticated && user) {
      // Check if user is admin (email matches admin email)
      // The isAdmin property might not exist on all User objects, default to false if undefined
      const isUserAdmin = user.email === 'sayboomcart@gmail.com' || (user as any).isAdmin === true;
      setIsAdmin(isUserAdmin);
      setCheckingAdmin(false);
    } else if (!isLoading && !isAuthenticated) {
      setCheckingAdmin(false);
    }
  }, [isLoading, isAuthenticated, user]);

  return (
    <Route path={path}>
      {() => {
        if (isLoading || checkingAdmin) {
          return (
            <div className="flex items-center justify-center min-h-screen">
              <div className="flex flex-col items-center">
                <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
                <p className="mt-4 text-center text-sm text-gray-500">Checking admin permissions...</p>
              </div>
            </div>
          );
        }

        if (!isAuthenticated) {
          return <Redirect to="/" />;
        }

        if (!isAdmin) {
          return (
            <div className="flex items-center justify-center min-h-screen">
              <div className="w-full max-w-md p-8 space-y-4 bg-gray-50 rounded-xl">
                <h1 className="text-2xl font-bold text-center text-red-600">Access Denied</h1>
                <p className="text-center text-gray-700">
                  You don't have permission to access the admin dashboard.
                </p>
                <div className="flex justify-center pt-4">
                  <a 
                    href="/"
                    className="px-4 py-2 text-sm font-medium text-white bg-orange-600 rounded-md hover:bg-orange-700"
                  >
                    Return to Home
                  </a>
                </div>
              </div>
            </div>
          );
        }

        return <Component />;
      }}
    </Route>
  );
};

export default AdminRoute;