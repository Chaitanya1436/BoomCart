import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { AudioProvider } from "./context/AudioContext";
import { AuthProvider } from "./context/AuthContext";
import { CartProvider } from "./context/CartContext";

createRoot(document.getElementById("root")!).render(
  <AuthProvider>
    <CartProvider>
      <AudioProvider>
        <App />
      </AudioProvider>
    </CartProvider>
  </AuthProvider>
);
