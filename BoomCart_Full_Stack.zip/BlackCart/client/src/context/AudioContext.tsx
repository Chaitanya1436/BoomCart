import { createContext, useContext, useState, useEffect, ReactNode } from "react";

// Create a persistent audio element that won't be recreated between renders
// This will ensure music playback continues during navigation
let globalAudioInstance: HTMLAudioElement | null = null;

// Array of music tracks
const musicTracks = [
  "/music/Music1.mp3",
  "/music/Music2.mp3",
  "/music/Music3.mp3",
  "/music/Music4.mp3",
  "/music/Music5.mp3"
];

// Get a random track from the music library
const getRandomTrack = (): string => {
  const randomIndex = Math.floor(Math.random() * musicTracks.length);
  return musicTracks[randomIndex];
};

interface AudioContextType {
  isPlaying: boolean;
  currentTrack: string;
}

const AudioContext = createContext<AudioContextType | undefined>(undefined);

interface AudioProviderProps {
  children: ReactNode;
}

export function AudioProvider({ children }: AudioProviderProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<string>(getRandomTrack());

  useEffect(() => {
    // Create audio element only once if it doesn't exist
    if (!globalAudioInstance) {
      const selectedTrack = currentTrack;
      globalAudioInstance = new Audio(selectedTrack);
      globalAudioInstance.loop = true;
      
      // Handle errors for the audio file
      globalAudioInstance.onerror = () => {
        console.error("Error loading audio file:", selectedTrack);
        // If there's an error with the current track, try another one
        if (musicTracks.length > 1) {
          const newTrack = getRandomTrack();
          setCurrentTrack(newTrack);
          if (globalAudioInstance) {
            globalAudioInstance.src = newTrack;
            globalAudioInstance.load();
          }
        }
      };
    }

    // Attempt to play on first user interaction
    const handleUserInteraction = () => {
      if (globalAudioInstance && !isPlaying) {
        globalAudioInstance.play()
          .then(() => setIsPlaying(true))
          .catch(error => console.error("Audio playback failed:", error));
        
        // Remove event listeners after successful play
        document.removeEventListener("click", handleUserInteraction);
        document.removeEventListener("touchstart", handleUserInteraction);
      }
    };

    document.addEventListener("click", handleUserInteraction);
    document.addEventListener("touchstart", handleUserInteraction);

    // Check if music is already playing
    if (globalAudioInstance.currentTime > 0 && !globalAudioInstance.paused) {
      setIsPlaying(true);
    }

    return () => {
      document.removeEventListener("click", handleUserInteraction);
      document.removeEventListener("touchstart", handleUserInteraction);
      // Don't stop the audio when component unmounts - we want it to keep playing
    };
  }, [currentTrack]);

  return (
    <AudioContext.Provider value={{ isPlaying, currentTrack }}>
      {children}
    </AudioContext.Provider>
  );
}

export function useAudio() {
  const context = useContext(AudioContext);
  if (context === undefined) {
    throw new Error("useAudio must be used within an AudioProvider");
  }
  return context;
}

// Export the context for direct access
export { AudioContext };
