import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ShoppingCart, Heart, Loader2, AlertTriangle } from "lucide-react";
import LoginModal from "@/components/LoginModal";
import { WishlistItem, Product } from "@shared/schema";

type WishlistItemWithProduct = WishlistItem & { product: Product };

const Wishlist = () => {
  const [wishlistItems, setWishlistItems] = useState<WishlistItemWithProduct[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  
  const { isAuthenticated } = useAuth();
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Fetch wishlist when authenticated
  useEffect(() => {
    const fetchWishlist = async () => {
      if (!isAuthenticated) {
        setIsLoading(false);
        return;
      }
      
      try {
        const response = await fetch("/api/wishlist", {
          credentials: "include",
        });
        
        if (!response.ok) {
          throw new Error("Failed to fetch wishlist");
        }
        
        const data = await response.json();
        setWishlistItems(data);
      } catch (error) {
        console.error("Error fetching wishlist:", error);
        toast({
          title: "Failed to load wishlist",
          variant: "destructive",
          duration: 3000,
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchWishlist();
  }, [isAuthenticated, toast]);
  
  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      setLoginModalOpen(true);
    }
  }, [isAuthenticated, isLoading]);
  
  const handleRemoveFromWishlist = async (id: number) => {
    try {
      await apiRequest("DELETE", `/api/wishlist/${id}`);
      
      // Update local state
      setWishlistItems(items => items.filter(item => item.id !== id));
      
      toast({
        title: "Removed from wishlist",
        duration: 2000,
      });
    } catch (error) {
      console.error("Error removing from wishlist:", error);
      toast({
        title: "Failed to remove from wishlist",
        variant: "destructive",
        duration: 3000,
      });
    }
  };
  
  const handleAddToCart = async (productId: number) => {
    try {
      await addToCart(productId);
      toast({
        title: "Added to cart",
        duration: 2000,
      });
    } catch (error) {
      console.error("Error adding to cart:", error);
      toast({
        title: "Failed to add to cart",
        variant: "destructive",
        duration: 3000,
      });
    }
  };
  
  // Format price in cents to dollars
  const formatPrice = (price: number) => {
    return (price / 100).toFixed(2);
  };
  
  if (!isAuthenticated && !isLoading) {
    return <LoginModal isOpen={loginModalOpen} onClose={() => navigate("/")} />;
  }
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center">
        <Loader2 className="h-12 w-12 text-accent animate-spin" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">My Wishlist</h1>
      
      {wishlistItems.length === 0 ? (
        <div className="text-center py-12">
          <div className="bg-gray-800 rounded-full p-6 inline-block mb-6">
            <Heart className="h-12 w-12 text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold mb-3">Your wishlist is empty</h2>
          <p className="text-gray-400 mb-6">Save items you love to your wishlist and find them here anytime.</p>
          <Link href="/category/all">
            <Button className="bg-accent hover:bg-accent/90">
              Discover Products
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {wishlistItems.map((item) => (
            <Card key={item.id} className="bg-gray-900 border-gray-800 overflow-hidden">
              <div className="h-48 bg-gray-800 relative">
                <Link href={`/product/${item.product.id}`}>
                  {item.product.isNew && (
                    <div className="absolute top-2 right-2 bg-green-600 text-white text-xs py-1 px-2 rounded">
                      NEW
                    </div>
                  )}
                  
                  {item.product.discountPrice && (
                    <div className="absolute top-2 right-2 bg-accent text-white text-xs py-1 px-2 rounded">
                      -{Math.round((1 - (item.product.price / item.product.discountPrice)) * 100)}%
                    </div>
                  )}
                </Link>
                
                <button 
                  className="absolute top-2 left-2 p-2 text-accent bg-gray-800 rounded-full hover:bg-gray-700"
                  onClick={() => handleRemoveFromWishlist(item.id)}
                >
                  <Heart className="h-4 w-4 fill-accent" />
                </button>
              </div>
              
              <CardContent className="p-4">
                <Link href={`/product/${item.product.id}`}>
                  <h3 className="text-sm text-gray-400">{item.product.subcategory}</h3>
                  <p className="font-medium mt-1 text-sm md:text-base">{item.product.name}</p>
                  
                  <div className="flex items-center mt-2">
                    <div className="text-yellow-400 text-xs">
                      {Array(Math.floor(item.product.rating || 0)).fill(null).map((_, i) => (
                        <span key={i}>★</span>
                      ))}
                      {(item.product.rating || 0) % 1 >= 0.5 && <span>★</span>}
                      {Array(5 - Math.ceil(item.product.rating || 0)).fill(null).map((_, i) => (
                        <span key={i} className="text-gray-500">★</span>
                      ))}
                    </div>
                    <span className="text-xs text-gray-400 ml-1">({item.product.reviewCount})</span>
                  </div>
                </Link>
                
                <div className="flex justify-between items-center mt-3">
                  <div>
                    <span className="text-accent font-bold text-sm md:text-base">
                      ${formatPrice(item.product.price)}
                    </span>
                    {item.product.discountPrice && (
                      <span className="text-gray-400 text-sm line-through ml-2">
                        ${formatPrice(item.product.discountPrice)}
                      </span>
                    )}
                  </div>
                  
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="bg-accent/10 border-accent/50 hover:bg-accent/20 text-accent"
                    onClick={() => handleAddToCart(item.product.id)}
                  >
                    <ShoppingCart className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Wishlist;
