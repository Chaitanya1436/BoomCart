import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow,
  TableFooter
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Clock, 
  Package, 
  ShoppingBag, 
  Search,
  TruckIcon, 
  HomeIcon,
  ClipboardCheck,
  PlusCircle,
  Pencil,
  Trash2,
  Tag
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Checkbox } from '@/components/ui/checkbox';

// Type definitions
interface User {
  id: number;
  username: string;
  email: string;
  displayName?: string;
  isAdmin: boolean;
}

interface OrderItem {
  id: number;
  orderId: number;
  productId: number;
  quantity: number;
  price: number;
  product: {
    id: number;
    name: string;
    price: number;
    imageUrl?: string;
  };
}

interface Order {
  id: number;
  userId: number;
  status: string;
  total: number;
  shippingAddress: string;
  paymentMethod: string;
  createdAt: string;
  items?: OrderItem[];
  user?: User;
  transactionId?: string;
  paymentNotes?: string;
}

interface DiscountCoupon {
  id: number;
  code: string;
  influencerName: string;
  discountPercentage: number;
  maxUsageCount: number;
  currentUsageCount: number | null;
  isActive: boolean;
  expiryDate: string | null;
  createdAt: string;
}

// Helper components
const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case 'pending_verification':
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Pending Verification</Badge>;
    case 'payment_verified':
      return <Badge variant="outline" className="bg-green-100 text-green-800">Payment Verified</Badge>;
    case 'payment_failed':
      return <Badge variant="outline" className="bg-red-100 text-red-800">Payment Failed</Badge>;
    case 'processing':
      return <Badge variant="outline" className="bg-blue-100 text-blue-800">Processing</Badge>;
    case 'shipped':
      return <Badge variant="outline" className="bg-purple-100 text-purple-800">Shipped</Badge>;
    case 'delivered':
      return <Badge variant="outline" className="bg-green-100 text-green-800">Delivered</Badge>;
    case 'cancelled':
      return <Badge variant="outline" className="bg-gray-100 text-gray-800">Cancelled</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

const StatusIcon = ({ status }: { status: string }) => {
  switch (status) {
    case 'pending_verification':
      return <Clock className="h-5 w-5 text-yellow-500" />;
    case 'payment_verified':
      return <CheckCircle2 className="h-5 w-5 text-green-500" />;
    case 'payment_failed':
      return <XCircle className="h-5 w-5 text-red-500" />;
    case 'processing':
      return <Package className="h-5 w-5 text-blue-500" />;
    case 'shipped':
      return <TruckIcon className="h-5 w-5 text-purple-500" />;
    case 'delivered':
      return <HomeIcon className="h-5 w-5 text-green-500" />;
    case 'cancelled':
      return <AlertCircle className="h-5 w-5 text-gray-500" />;
    default:
      return <ShoppingBag className="h-5 w-5" />;
  }
};

// Main admin dashboard component
const AdminDashboard = () => {
  const [location, setLocation] = useLocation();
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [verifyDialogOpen, setVerifyDialogOpen] = useState(false);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [verificationNotes, setVerificationNotes] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [couponDialogOpen, setCouponDialogOpen] = useState(false);
  const [selectedCouponId, setSelectedCouponId] = useState<number | null>(null);
  const [couponFormData, setCouponFormData] = useState({
    code: '',
    influencerName: '',
    discountPercentage: 10,
    maxUsageCount: 100,
    isActive: true,
    expiryDate: ''
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all orders for admin
  const { data: orders = [], isLoading: ordersLoading } = useQuery({
    queryKey: ['/api/admin/orders'],
    queryFn: async () => {
      const res = await fetch('/api/admin/orders');
      if (!res.ok) {
        throw new Error('Failed to fetch orders');
      }
      return res.json();
    }
  });

  // Fetch selected order details
  const { data: orderDetails, isLoading: orderDetailsLoading } = useQuery({
    queryKey: ['/api/admin/orders', selectedOrderId],
    queryFn: async () => {
      if (!selectedOrderId) return null;
      const res = await fetch(`/api/admin/orders/${selectedOrderId}`);
      if (!res.ok) {
        throw new Error('Failed to fetch order details');
      }
      return res.json();
    },
    enabled: !!selectedOrderId
  });

  // Mutation to verify payment
  const verifyPaymentMutation = useMutation({
    mutationFn: async ({ orderId, isVerified, notes }: { orderId: number, isVerified: boolean, notes: string }) => {
      const res = await apiRequest('PUT', `/api/admin/orders/${orderId}/verify-payment`, {
        isVerified,
        notes
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/orders'] });
      if (selectedOrderId) {
        queryClient.invalidateQueries({ queryKey: ['/api/admin/orders', selectedOrderId] });
      }
      setVerifyDialogOpen(false);
      setVerificationNotes('');
      toast({
        title: 'Payment verification updated',
        description: 'The order status has been updated successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error updating payment verification',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  // Mutation to update order status
  const updateStatusMutation = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: number, status: string }) => {
      const res = await apiRequest('PUT', `/api/admin/orders/${orderId}/status`, {
        status
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/orders'] });
      if (selectedOrderId) {
        queryClient.invalidateQueries({ queryKey: ['/api/admin/orders', selectedOrderId] });
      }
      setStatusDialogOpen(false);
      toast({
        title: 'Order status updated',
        description: 'The order status has been updated successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error updating order status',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  // Handle payment verification
  const handleVerifyPayment = (isVerified: boolean) => {
    if (!selectedOrderId) return;
    
    verifyPaymentMutation.mutate({
      orderId: selectedOrderId,
      isVerified,
      notes: verificationNotes
    });
  };

  // Handle status update
  const handleUpdateStatus = () => {
    if (!selectedOrderId || !selectedStatus) return;
    
    updateStatusMutation.mutate({
      orderId: selectedOrderId,
      status: selectedStatus
    });
  };

  // Filter orders by search query
  const filteredOrders = searchQuery 
    ? orders.filter((order: Order) => 
        order.id.toString().includes(searchQuery) ||
        (order.transactionId && order.transactionId.toLowerCase().includes(searchQuery.toLowerCase())) ||
        order.status.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : orders;

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  // Fetch all coupons
  const { data: coupons = [], isLoading: couponLoading } = useQuery({
    queryKey: ['/api/admin/coupons'],
    queryFn: async () => {
      const res = await fetch('/api/admin/coupons');
      if (!res.ok) {
        throw new Error('Failed to fetch coupons');
      }
      return res.json();
    }
  });

  // Mutation to create/update coupons
  const couponMutation = useMutation({
    mutationFn: async (couponData: Partial<DiscountCoupon> & { id?: number }) => {
      const { id, ...data } = couponData;
      const method = id ? 'PUT' : 'POST';
      const url = id ? `/api/admin/coupons/${id}` : '/api/admin/coupons';
      
      const res = await apiRequest(method, url, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/coupons'] });
      setCouponDialogOpen(false);
      toast({
        title: selectedCouponId ? 'Coupon updated' : 'Coupon created',
        description: `The coupon has been ${selectedCouponId ? 'updated' : 'created'} successfully.`,
      });
    },
    onError: (error) => {
      toast({
        title: `Error ${selectedCouponId ? 'updating' : 'creating'} coupon`,
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  // Mutation to toggle coupon status
  const toggleCouponStatusMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number, isActive: boolean }) => {
      const res = await apiRequest('PUT', `/api/admin/coupons/${id}/toggle-status`, {
        isActive
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/coupons'] });
      toast({
        title: 'Coupon status updated',
        description: 'The coupon status has been updated successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error updating coupon status',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  // Handle coupon form field changes
  const handleCouponFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    
    // Handle number inputs
    if (type === 'number') {
      setCouponFormData({
        ...couponFormData,
        [name]: parseInt(value, 10)
      });
    } else {
      setCouponFormData({
        ...couponFormData,
        [name]: value
      });
    }
  };

  // Handle coupon form submission
  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const payload = {
      ...couponFormData
    };
    
    if (selectedCouponId) {
      payload.id = selectedCouponId;
    }
    
    couponMutation.mutate(payload);
  };

  // Handle edit coupon
  const handleEditCoupon = (coupon: DiscountCoupon) => {
    setSelectedCouponId(coupon.id);
    setCouponFormData({
      code: coupon.code,
      influencerName: coupon.influencerName,
      discountPercentage: coupon.discountPercentage,
      maxUsageCount: coupon.maxUsageCount,
      isActive: coupon.isActive,
      expiryDate: coupon.expiryDate ? new Date(coupon.expiryDate).toISOString().split('T')[0] : ''
    });
    setCouponDialogOpen(true);
  };

  // Handle toggle coupon status
  const handleToggleCouponStatus = (id: number, isActive: boolean) => {
    toggleCouponStatusMutation.mutate({ id, isActive });
  };

  // Format price in INR
  const formatPrice = (price: number) => {
    return `₹${(price / 100).toFixed(2)}`;
  };

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <Button variant="outline" onClick={() => setLocation('/')}>
          Back to Store
        </Button>
      </div>

      <Tabs defaultValue="orders" className="space-y-4">
        <TabsList>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="coupons">Discount Coupons</TabsTrigger>
        </TabsList>

        <TabsContent value="orders" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                <div>
                  <CardTitle>All Orders</CardTitle>
                  <CardDescription>
                    Manage and view all customer orders
                  </CardDescription>
                </div>
                <div className="relative w-full md:w-64">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search orders..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {ordersLoading ? (
                <div className="flex justify-center p-4">
                  <div className="animate-spin w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredOrders.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-4">
                            No orders found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredOrders.map((order: Order) => (
                          <TableRow key={order.id}>
                            <TableCell>{order.id}</TableCell>
                            <TableCell>{formatDate(order.createdAt)}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <StatusIcon status={order.status} />
                                <StatusBadge status={order.status} />
                              </div>
                            </TableCell>
                            <TableCell>{formatPrice(order.total)}</TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setSelectedOrderId(order.id)}
                              >
                                View Details
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {selectedOrderId && (
            <Card>
              <CardHeader>
                <CardTitle>Order Details - #{selectedOrderId}</CardTitle>
                <CardDescription>
                  View and manage order information
                </CardDescription>
              </CardHeader>
              <CardContent>
                {orderDetailsLoading ? (
                  <div className="flex justify-center p-4">
                    <div className="animate-spin w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full"></div>
                  </div>
                ) : orderDetails ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <h3 className="text-lg font-medium">Order Information</h3>
                          <div className="grid grid-cols-2 gap-2 mt-2">
                            <div className="text-sm text-gray-500">Status:</div>
                            <div className="text-sm font-medium">
                              <StatusBadge status={orderDetails.status} />
                            </div>
                            <div className="text-sm text-gray-500">Order Date:</div>
                            <div className="text-sm">{formatDate(orderDetails.createdAt)}</div>
                            <div className="text-sm text-gray-500">Total Amount:</div>
                            <div className="text-sm">{formatPrice(orderDetails.total)}</div>
                            <div className="text-sm text-gray-500">Payment Method:</div>
                            <div className="text-sm">{orderDetails.paymentMethod}</div>
                            {orderDetails.transactionId && (
                              <>
                                <div className="text-sm text-gray-500">Transaction ID:</div>
                                <div className="text-sm font-medium">{orderDetails.transactionId}</div>
                              </>
                            )}
                          </div>
                        </div>

                        <div>
                          <h3 className="text-lg font-medium">Shipping Address</h3>
                          <p className="text-sm mt-2 whitespace-pre-line">{orderDetails.shippingAddress}</p>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-medium">Order Items</h3>
                        <div className="rounded-md border mt-2">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Product</TableHead>
                                <TableHead>Quantity</TableHead>
                                <TableHead className="text-right">Price</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {orderDetails.items?.map((item: OrderItem) => (
                                <TableRow key={item.id}>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      {item.product.imageUrl ? (
                                        <div className="w-10 h-10 rounded bg-gray-200 overflow-hidden">
                                          <img
                                            src={item.product.imageUrl}
                                            alt={item.product.name}
                                            className="w-full h-full object-cover"
                                          />
                                        </div>
                                      ) : (
                                        <div className="w-10 h-10 rounded bg-gray-200 flex items-center justify-center">
                                          <Package className="w-5 h-5 text-gray-500" />
                                        </div>
                                      )}
                                      <span className="text-sm">{item.product.name}</span>
                                    </div>
                                  </TableCell>
                                  <TableCell>{item.quantity}</TableCell>
                                  <TableCell className="text-right">{formatPrice(item.price)}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                            <TableFooter>
                              <TableRow>
                                <TableCell colSpan={2}>Total</TableCell>
                                <TableCell className="text-right">{formatPrice(orderDetails.total)}</TableCell>
                              </TableRow>
                            </TableFooter>
                          </Table>
                        </div>
                      </div>
                    </div>

                    {/* Order Actions Section */}
                    <div className="rounded-md border p-4 bg-gray-50">
                      <h3 className="text-lg font-medium mb-4">Order Actions</h3>
                      <div className="flex flex-wrap gap-2">
                        {orderDetails.status === 'pending_verification' && (
                          <Button 
                            variant="default"
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => {
                              setVerifyDialogOpen(true);
                            }}
                          >
                            <CheckCircle2 className="w-4 h-4 mr-2" />
                            Verify Payment
                          </Button>
                        )}
                        <Button 
                          variant="outline"
                          onClick={() => {
                            setStatusDialogOpen(true);
                          }}
                        >
                          <ClipboardCheck className="w-4 h-4 mr-2" />
                          Update Status
                        </Button>
                      </div>
                    </div>

                    {/* Payment Verification Notes (if any) */}
                    {orderDetails.paymentNotes && (
                      <div className="rounded-md border p-4 bg-gray-50">
                        <h3 className="text-lg font-medium mb-2">Payment Notes</h3>
                        <p className="text-sm">{orderDetails.paymentNotes}</p>
                      </div>
                    )}
                  </div>
                ) : (
                  <p>No order details found</p>
                )}
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  onClick={() => setSelectedOrderId(null)}
                >
                  Close Details
                </Button>
              </CardFooter>
            </Card>
          )}

          {/* Payment Verification Dialog */}
          <Dialog open={verifyDialogOpen} onOpenChange={setVerifyDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Verify Payment</DialogTitle>
                <DialogDescription>
                  Confirm if you have received the payment for this order.
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="verification-notes">Verification Notes (optional)</Label>
                  <Textarea
                    id="verification-notes"
                    placeholder="Add any notes about the payment verification..."
                    value={verificationNotes}
                    onChange={(e) => setVerificationNotes(e.target.value)}
                  />
                </div>
              </div>

              <DialogFooter className="sm:justify-start">
                <Button
                  type="button"
                  variant="default" 
                  className="bg-green-600 hover:bg-green-700"
                  onClick={() => handleVerifyPayment(true)}
                  disabled={verifyPaymentMutation.isPending}
                >
                  {verifyPaymentMutation.isPending ? (
                    <div className="flex items-center">
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                      Processing
                    </div>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      Confirm Payment
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  variant="destructive"
                  onClick={() => handleVerifyPayment(false)}
                  disabled={verifyPaymentMutation.isPending}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject Payment
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setVerifyDialogOpen(false)}
                >
                  Cancel
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Update Status Dialog */}
          <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Update Order Status</DialogTitle>
                <DialogDescription>
                  Change the current status of this order.
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="order-status">New Status</Label>
                  <Select
                    value={selectedStatus}
                    onValueChange={setSelectedStatus}
                  >
                    <SelectTrigger id="order-status">
                      <SelectValue placeholder="Select new status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending_verification">Pending Verification</SelectItem>
                      <SelectItem value="payment_verified">Payment Verified</SelectItem>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="shipped">Shipped</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <DialogFooter className="sm:justify-start">
                <Button
                  type="button"
                  variant="default"
                  onClick={handleUpdateStatus}
                  disabled={updateStatusMutation.isPending || !selectedStatus}
                >
                  {updateStatusMutation.isPending ? (
                    <div className="flex items-center">
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                      Updating
                    </div>
                  ) : (
                    <>
                      <ClipboardCheck className="w-4 h-4 mr-2" />
                      Update Status
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStatusDialogOpen(false)}
                >
                  Cancel
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="payments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pending Payment Verification</CardTitle>
              <CardDescription>
                Review and verify payments for recent orders
              </CardDescription>
            </CardHeader>
            <CardContent>
              {ordersLoading ? (
                <div className="flex justify-center p-4">
                  <div className="animate-spin w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Transaction ID</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders
                        .filter((order: Order) => order.status === 'pending_verification')
                        .map((order: Order) => (
                          <TableRow key={order.id}>
                            <TableCell>{order.id}</TableCell>
                            <TableCell>{formatDate(order.createdAt)}</TableCell>
                            <TableCell>{formatPrice(order.total)}</TableCell>
                            <TableCell>{order.transactionId || '-'}</TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="default"
                                size="sm"
                                className="bg-green-600 hover:bg-green-700 mr-2"
                                onClick={() => {
                                  setSelectedOrderId(order.id);
                                  setVerifyDialogOpen(true);
                                }}
                              >
                                Verify
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedOrderId(order.id);
                                }}
                              >
                                Details
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      {orders.filter((order: Order) => order.status === 'pending_verification').length === 0 && (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-4">
                            No orders pending verification
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="coupons" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                <div>
                  <CardTitle>Discount Coupons</CardTitle>
                  <CardDescription>
                    Manage influencer discount coupons and their usage
                  </CardDescription>
                </div>
                <Button 
                  variant="default" 
                  onClick={() => {
                    setCouponDialogOpen(true);
                    setSelectedCouponId(null);
                    setCouponFormData({
                      code: '',
                      influencerName: '',
                      discountPercentage: 10,
                      maxUsageCount: 100,
                      isActive: true,
                      expiryDate: ''
                    });
                  }}
                >
                  Create New Coupon
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {couponLoading ? (
                <div className="flex justify-center p-4">
                  <div className="animate-spin w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Influencer</TableHead>
                        <TableHead>Discount</TableHead>
                        <TableHead>Usage</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {coupons.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-4">
                            No coupons found. Create your first coupon!
                          </TableCell>
                        </TableRow>
                      ) : (
                        coupons.map((coupon: DiscountCoupon) => (
                          <TableRow key={coupon.id}>
                            <TableCell className="font-medium">{coupon.code}</TableCell>
                            <TableCell>{coupon.influencerName}</TableCell>
                            <TableCell>{coupon.discountPercentage}%</TableCell>
                            <TableCell>
                              {coupon.currentUsageCount || 0} / {coupon.maxUsageCount}
                            </TableCell>
                            <TableCell>
                              {coupon.isActive ? (
                                <Badge variant="outline" className="bg-green-100 text-green-800">Active</Badge>
                              ) : (
                                <Badge variant="outline" className="bg-gray-100 text-gray-800">Inactive</Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="outline"
                                size="sm"
                                className="mr-2"
                                onClick={() => handleEditCoupon(coupon)}
                              >
                                Edit
                              </Button>
                              <Button
                                variant={coupon.isActive ? "destructive" : "default"}
                                size="sm"
                                onClick={() => handleToggleCouponStatus(coupon.id, !coupon.isActive)}
                              >
                                {coupon.isActive ? 'Deactivate' : 'Activate'}
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Coupon Form Dialog */}
          <Dialog open={couponDialogOpen} onOpenChange={setCouponDialogOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>{selectedCouponId ? 'Edit Coupon' : 'Create New Coupon'}</DialogTitle>
                <DialogDescription>
                  {selectedCouponId 
                    ? 'Update the discount coupon details below.' 
                    : 'Fill in the details to create a new discount coupon.'}
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleCouponSubmit} className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="code">Coupon Code</Label>
                    <Input
                      id="code"
                      name="code"
                      value={couponFormData.code}
                      onChange={handleCouponFormChange}
                      placeholder="SUMMER20"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="influencerName">Influencer Name</Label>
                    <Input
                      id="influencerName"
                      name="influencerName"
                      value={couponFormData.influencerName}
                      onChange={handleCouponFormChange}
                      placeholder="John Doe"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="discountPercentage">Discount (%)</Label>
                    <Input
                      id="discountPercentage"
                      name="discountPercentage"
                      type="number"
                      min="1"
                      max="100"
                      value={couponFormData.discountPercentage.toString()}
                      onChange={handleCouponFormChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxUsageCount">Max Usage Count</Label>
                    <Input
                      id="maxUsageCount"
                      name="maxUsageCount"
                      type="number"
                      min="1"
                      value={couponFormData.maxUsageCount.toString()}
                      onChange={handleCouponFormChange}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="expiryDate">Expiry Date (Optional)</Label>
                    <Input
                      id="expiryDate"
                      name="expiryDate"
                      type="date"
                      value={couponFormData.expiryDate}
                      onChange={handleCouponFormChange}
                    />
                  </div>
                  <div className="flex items-center pt-6">
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="isActive" 
                        name="isActive"
                        checked={couponFormData.isActive}
                        onCheckedChange={(checked) => 
                          setCouponFormData({
                            ...couponFormData,
                            isActive: checked as boolean
                          })
                        }
                      />
                      <label
                        htmlFor="isActive"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Active
                      </label>
                    </div>
                  </div>
                </div>

                <DialogFooter className="pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setCouponDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={couponMutation.isPending}
                  >
                    {couponMutation.isPending ? (
                      <div className="flex items-center">
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                        {selectedCouponId ? 'Updating...' : 'Creating...'}
                      </div>
                    ) : (
                      selectedCouponId ? 'Update Coupon' : 'Create Coupon'
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;