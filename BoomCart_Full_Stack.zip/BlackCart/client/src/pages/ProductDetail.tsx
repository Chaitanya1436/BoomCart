import { useState, useEffect } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Product } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Star, 
  StarHalf, 
  Heart, 
  ShoppingCart,

  Minus,
  Plus,
  Share2,
  Truck,
  RotateCcw,
  ShieldCheck,
  ChevronRight,
  Loader2
} from "lucide-react";
import LoginModal from "@/components/LoginModal";
import ProductGrid from "@/components/ProductGrid";
import { formatPrice } from "@/lib/utils";

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  
  const { addToCart } = useCart();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await fetch(`/api/products/${id}`);
        
        if (!response.ok) {
          throw new Error('Product not found');
        }
        
        const data = await response.json();
        setProduct(data);
        
        // Fetch related products
        const relatedRes = await fetch(`/api/products?category=${data.category}&limit=5`);
        const relatedData = await relatedRes.json();
        setRelatedProducts(
          relatedData.products.filter((p: Product) => p.id !== parseInt(id))
        );
      } catch (error) {
        console.error('Error fetching product:', error);
        navigate('/not-found');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProduct();
  }, [id, navigate]);
  
  const handleAddToCart = () => {
    if (!isAuthenticated) {
      setLoginModalOpen(true);
      return;
    }
    
    if (product) {
      addToCart(product.id, quantity);
    }
  };
  
  const handleAddToWishlist = async () => {
    if (!isAuthenticated) {
      setLoginModalOpen(true);
      return;
    }
    
    try {
      await apiRequest("POST", "/api/wishlist", { productId: parseInt(id) });
      setIsWishlisted(true);
      toast({
        title: "Added to wishlist",
        duration: 2000,
      });
    } catch (error) {
      console.error("Error adding to wishlist:", error);
      toast({
        title: "Failed to add to wishlist",
        variant: "destructive",
        duration: 3000,
      });
    }
  };
  
  // We now use the util function for formatting price
  
  // Render stars based on rating
  const renderRating = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="fill-yellow-400 text-yellow-400 h-5 w-5" />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="fill-yellow-400 text-yellow-400 h-5 w-5" />);
    }
    
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-yellow-400 h-5 w-5" />);
    }
    
    return stars;
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center">
        <Loader2 className="h-12 w-12 text-accent animate-spin" />
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Product not found</h1>
          <p className="text-gray-400">The product you're looking for doesn't exist or has been removed.</p>
          <Link href="/category/all">
            <Button className="mt-6 bg-accent hover:bg-accent/90">
              Browse All Products
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <>
      <div className="container mx-auto px-4 py-6">
        {/* Breadcrumb */}
        <div className="flex items-center text-sm text-gray-400 mb-6">
          <Link href="/">Home</Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <Link href={`/category/${product.category}`}>{product.category}</Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <Link href={`/category/${product.subcategory}`}>{product.subcategory}</Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <span className="text-gray-300 truncate">{product.name}</span>
        </div>
        
        {/* Product Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Product Image Gallery */}
          <div className="space-y-4">
            {/* Main Image */}
            <div className="bg-gray-900 rounded-lg overflow-hidden h-[400px] md:h-[500px] relative group shadow-xl">
              {product.imageUrl ? (
                <img 
                  src={product.imageUrl} 
                  alt={product.name} 
                  className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gray-800 text-gray-500">
                  <p>No image available</p>
                </div>
              )}
              
              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {product.isNew && (
                  <div className="bg-green-600 text-white text-xs py-1 px-3 rounded shadow-lg">
                    NEW
                  </div>
                )}
                
                {product.brand && (
                  <div className="bg-gray-800/80 backdrop-blur-sm text-white text-xs py-1 px-3 rounded shadow-lg">
                    {product.brand}
                  </div>
                )}
              </div>
              
              {/* Discount badge */}
              {product.discountPrice && product.price < product.discountPrice && (
                <div className="absolute top-4 right-4 bg-accent text-white font-bold py-1 px-3 rounded-full shadow-lg">
                  -{Math.round(((product.discountPrice - product.price) / product.discountPrice) * 100)}% OFF
                </div>
              )}
              
              {/* Availability badge */}
              <div className={`absolute bottom-4 left-4 text-xs py-1 px-3 rounded-full shadow-lg ${
                product.inStock 
                  ? 'bg-green-600/90 text-white' 
                  : 'bg-gray-700/90 text-gray-300'
              }`}>
                {product.inStock ? 'In Stock' : 'Out of Stock'}
              </div>
              
              {/* Image zoom/fullscreen button */}
              <button className="absolute bottom-4 right-4 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-200 opacity-0 group-hover:opacity-100">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="15 3 21 3 21 9"></polyline>
                  <polyline points="9 21 3 21 3 15"></polyline>
                  <line x1="21" y1="3" x2="14" y2="10"></line>
                  <line x1="3" y1="21" x2="10" y2="14"></line>
                </svg>
              </button>
            </div>
            
            {/* Thumbnail Images - for future implementation with multiple images */}
            <div className="grid grid-cols-5 gap-2">
              {[1, 2, 3, 4, 5].map((_, index) => (
                <div 
                  key={index} 
                  className={`h-20 rounded-md overflow-hidden cursor-pointer border-2 ${
                    index === 0 ? 'border-accent' : 'border-transparent hover:border-gray-600'
                  }`}
                >
                  {product.imageUrl ? (
                    <img 
                      src={product.imageUrl} 
                      alt={`${product.name} thumbnail ${index + 1}`} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gray-800 flex items-center justify-center text-xs text-gray-500">
                      {index + 1}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Product Info */}
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex">
                {renderRating(product.rating || 0)}
              </div>
              <span className="text-gray-400 ml-2">({product.reviewCount} reviews)</span>
              
              {product.brand && (
                <>
                  <Separator orientation="vertical" className="mx-3 h-4 bg-gray-700" />
                  <span className="text-gray-300">Brand: <span className="text-accent">{product.brand}</span></span>
                </>
              )}
            </div>
            
            <div className="mb-6">
              <div className="flex items-end mb-2">
                <span className="text-3xl font-bold text-white mr-3">
                  {formatPrice(product.price)}
                </span>
                
                {product.discountPrice && (
                  <span className="text-xl text-gray-400 line-through">
                    {formatPrice(product.discountPrice)}
                  </span>
                )}
              </div>
              
              <p className="text-green-500 text-sm">
                {product.inStock ? "In Stock" : "Out of Stock"}
              </p>
            </div>
            
            <Separator className="my-6 bg-gray-800" />
            
            <div className="mb-6">
              <p className="text-gray-300 mb-4">{product.description}</p>
              
              {/* Size and Color options would go here */}
              {product.size && (
                <div className="mb-4">
                  <span className="block text-sm text-gray-400 mb-2">Size:</span>
                  <div className="flex flex-wrap gap-2">
                    <Button variant="outline" className="border-gray-700 bg-gray-800">
                      {product.size}
                    </Button>
                  </div>
                </div>
              )}
              
              {product.color && (
                <div className="mb-4">
                  <span className="block text-sm text-gray-400 mb-2">Color:</span>
                  <div className="flex flex-wrap gap-2">
                    <Button variant="outline" className="border-gray-700 bg-gray-800">
                      {product.color}
                    </Button>
                  </div>
                </div>
              )}
            </div>
            
            {/* Quantity and Add to Cart */}
            <div className="flex flex-wrap items-center gap-4 mb-6">
              <div className="flex items-center border border-gray-700 rounded-md">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-10 w-10 text-gray-400 hover:text-white hover:bg-gray-800"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="w-10 text-center">{quantity}</span>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-10 w-10 text-gray-400 hover:text-white hover:bg-gray-800"
                  onClick={() => setQuantity(quantity + 1)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              
              <Button 
                className="flex-1 bg-accent hover:bg-accent/90 text-white px-6 py-3 rounded-md font-medium flex items-center justify-center gap-2"
                onClick={handleAddToCart}
                disabled={!product.inStock}
              >
                <ShoppingCart className="h-5 w-5" />
                Add to Cart
              </Button>
              
              <Button 
                variant="outline" 
                size="icon" 
                className={`h-10 w-10 ${isWishlisted ? 'text-accent border-accent' : 'text-gray-400 border-gray-700'} hover:text-accent hover:border-accent`}
                onClick={handleAddToWishlist}
              >
                <Heart className={`h-5 w-5 ${isWishlisted ? 'fill-accent' : ''}`} />
              </Button>
              
              <Button 
                variant="outline" 
                size="icon" 
                className="h-10 w-10 text-gray-400 border-gray-700 hover:text-white hover:border-white"
              >
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
            
            {/* Shipping Info */}
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-start gap-3">
                  <Truck className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Free Shipping</p>
                    <p className="text-sm text-gray-400">On orders over ₹3,999</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <RotateCcw className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">30 Days Return</p>
                    <p className="text-sm text-gray-400">If goods have problems</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <ShieldCheck className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium">Secure Payment</p>
                    <p className="text-sm text-gray-400">100% secure payment</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        {/* Product Details Accordion */}
        <div className="mb-12">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="description" className="border-gray-800">
              <AccordionTrigger className="text-lg font-medium">
                Product Description
              </AccordionTrigger>
              <AccordionContent className="text-gray-300">
                <p className="mb-4">{product.description}</p>
                
                <ul className="list-disc list-inside space-y-2 text-gray-400">
                  <li>Brand: {product.brand}</li>
                  {product.color && <li>Color: {product.color}</li>}
                  {product.size && <li>Size: {product.size}</li>}
                  <li>Category: {product.category}</li>
                  <li>Subcategory: {product.subcategory}</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="shipping" className="border-gray-800">
              <AccordionTrigger className="text-lg font-medium">
                Shipping & Returns
              </AccordionTrigger>
              <AccordionContent className="text-gray-300">
                <p className="mb-4">
                  We offer free standard shipping on all orders over ₹3,999. Delivery typically takes 3-5 business days.
                </p>
                <p className="mb-4">
                  For orders under ₹3,999, a flat shipping rate of ₹199 will be applied.
                </p>
                <p>
                  Returns are accepted within 30 days of purchase. Items must be unused and in their original packaging.
                </p>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="reviews" className="border-gray-800">
              <AccordionTrigger className="text-lg font-medium">
                Reviews ({product.reviewCount})
              </AccordionTrigger>
              <AccordionContent className="text-gray-300">
                <div className="flex items-center mb-4">
                  <div className="flex">
                    {renderRating(product.rating || 0)}
                  </div>
                  <span className="ml-2">{product.rating?.toFixed(1)} out of 5</span>
                </div>
                <p className="text-gray-400">
                  Based on {product.reviewCount} reviews
                </p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
        
        {/* Related Products */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Related Products</h2>
          
          <ProductGrid initialProducts={relatedProducts} isHomePage />
        </div>
      </div>
      
      <LoginModal isOpen={loginModalOpen} onClose={() => setLoginModalOpen(false)} />
    </>
  );
};

export default ProductDetail;
