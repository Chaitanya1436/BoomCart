import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Plus, Minus, ShoppingCart, ArrowRight, Loader2 } from "lucide-react";
import LoginModal from "@/components/LoginModal";
import { formatPrice } from "@/lib/utils";

const Cart = () => {
  const { cartItems, updateQuantity, removeFromCart, getCartTotal, isLoading } = useCart();
  const { isAuthenticated, user } = useAuth();
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      setLoginModalOpen(true);
    }
  }, [isAuthenticated, isLoading]);
  
  const handleCheckout = () => {
    if (!isAuthenticated) {
      setLoginModalOpen(true);
      return;
    }
    
    navigate("/checkout");
  };
  
  const subtotal = getCartTotal();
  const shippingCost = subtotal > 0 ? 10000 : 0; // ₹100 shipping
  const tax = Math.round(subtotal * 0.18); // 18% GST tax
  const total = subtotal + shippingCost + tax;
  
  if (!isAuthenticated && !isLoading) {
    return <LoginModal isOpen={loginModalOpen} onClose={() => navigate("/")} />;
  }
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center">
        <Loader2 className="h-12 w-12 text-accent animate-spin" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Shopping Cart</h1>
      
      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <div className="bg-gray-800 rounded-full p-6 inline-block mb-6">
            <ShoppingCart className="h-12 w-12 text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold mb-3">Your cart is empty</h2>
          <p className="text-gray-400 mb-6">Looks like you haven't added any products to your cart yet.</p>
          <Link href="/category/all">
            <Button className="bg-accent hover:bg-accent/90">
              Start Shopping
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items - Takes up 2/3 of the space on large screens */}
          <div className="lg:col-span-2">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-0">
                <Table>
                  <TableHeader className="bg-gray-800">
                    <TableRow className="border-gray-700">
                      <TableHead className="text-gray-300">Product</TableHead>
                      <TableHead className="text-gray-300 text-right">Price</TableHead>
                      <TableHead className="text-gray-300 text-center">Quantity</TableHead>
                      <TableHead className="text-gray-300 text-right">Subtotal</TableHead>
                      <TableHead className="w-[50px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cartItems.map((item) => (
                      <TableRow key={item.id} className="border-gray-800">
                        <TableCell>
                          <div className="flex items-center space-x-4">
                            <div className="h-16 w-16 bg-gray-800 rounded"></div>
                            <div>
                              <p className="font-medium">{item.product.name}</p>
                              <p className="text-sm text-gray-400">
                                {item.product.size && `Size: ${item.product.size}`}
                                {item.product.size && item.product.color && " | "}
                                {item.product.color && `Color: ${item.product.color}`}
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          {formatPrice(item.product.price)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center justify-center">
                            <Button 
                              variant="outline" 
                              size="icon" 
                              className="h-8 w-8 p-0 border-gray-700"
                              onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                              disabled={item.quantity <= 1}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-10 text-center">{item.quantity}</span>
                            <Button 
                              variant="outline" 
                              size="icon" 
                              className="h-8 w-8 p-0 border-gray-700"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          {formatPrice(item.product.price * item.quantity)}
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => removeFromCart(item.id)}
                            className="text-gray-400 hover:text-white hover:bg-gray-800"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter className="flex justify-between p-4 border-t border-gray-800">
                <Link href="/category/all">
                  <Button variant="outline" className="border-gray-700 text-gray-300">
                    <ArrowRight className="h-4 w-4 mr-2 rotate-180" />
                    Continue Shopping
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
          
          {/* Order Summary - Takes up 1/3 of the space on large screens */}
          <div>
            <Card className="bg-gray-900 border-gray-800 sticky top-24">
              <CardContent className="p-6">
                <h2 className="text-xl font-bold mb-4">Order Summary</h2>
                
                <div className="space-y-3 mb-4">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Subtotal:</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Shipping:</span>
                    <span>{formatPrice(shippingCost)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">GST (18%):</span>
                    <span>{formatPrice(tax)}</span>
                  </div>
                  
                  <Separator className="bg-gray-800" />
                  
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total:</span>
                    <span>{formatPrice(total)}</span>
                  </div>
                </div>
                

              </CardContent>
              <CardFooter className="p-6 pt-0">
                <Button 
                  className="w-full bg-accent hover:bg-accent/90 py-6"
                  onClick={handleCheckout}
                  disabled={cartItems.length === 0}
                >
                  Proceed to Checkout
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
