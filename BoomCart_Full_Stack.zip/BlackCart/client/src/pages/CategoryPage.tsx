import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import FilterSidebar from "@/components/FilterSidebar";
import ProductGrid from "@/components/ProductGrid";
import { Separator } from "@/components/ui/separator";
import { Category } from "@shared/schema";
import { Loader2 } from "lucide-react";

const CategoryPage = () => {
  const { category } = useParams<{ category: string }>();
  const [, setLocation] = useLocation();
  const [categoryData, setCategoryData] = useState<Category | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState<Record<string, any>>({});
  
  // Parse search query from URL
  const searchParams = new URLSearchParams(window.location.search);
  const searchQuery = searchParams.get('search');
  
  useEffect(() => {
    const fetchCategoryData = async () => {
      try {
        // If it's the "all" category, we don't need to fetch specific category
        if (category?.toLowerCase() === 'all') {
          setCategoryData({
            id: 0,
            name: 'All Products',
            isLocked: false,
            productCount: 0,
          });
          setIsLoading(false);
          return;
        }
        
        const response = await fetch('/api/categories');
        const categories = await response.json();
        
        const foundCategory = categories.find(
          (c: Category) => c.name.toLowerCase() === decodeURIComponent(category).toLowerCase()
        );
        
        if (foundCategory) {
          setCategoryData(foundCategory);
          
          // If category is locked, redirect to home page
          if (foundCategory.isLocked) {
            setLocation('/');
          }
        } else {
          // Category not found, redirect to 404
          setLocation('/not-found');
        }
      } catch (error) {
        console.error('Error fetching category:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchCategoryData();
  }, [category, setLocation]);
  
  const handleFilterChange = (newFilters: Record<string, any>) => {
    setFilters(newFilters);
  };
  
  // Add search query to filters if present
  useEffect(() => {
    if (searchQuery) {
      setFilters(prev => ({ ...prev, search: searchQuery }));
    }
  }, [searchQuery]);
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center">
        <Loader2 className="h-12 w-12 text-accent animate-spin" />
      </div>
    );
  }
  
  if (!categoryData) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Category not found</h1>
          <p className="text-gray-400">The category you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Category Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold">
          {searchQuery 
            ? `Search results for "${searchQuery}"` 
            : categoryData.name
          }
        </h1>
        {categoryData.productCount > 0 && !searchQuery && (
          <p className="text-gray-400 mt-2">{categoryData.productCount}+ products</p>
        )}
      </div>
      
      <Separator className="mb-6 bg-gray-800" />
      
      {/* Filter Controls */}
      <FilterSidebar onFilterChange={handleFilterChange} category={category} />
      
      {/* Product Grid with Infinite Scroll */}
      <ProductGrid 
        category={category === 'all' ? undefined : categoryData.name} 
        filters={filters} 
      />
    </div>
  );
};

export default CategoryPage;
