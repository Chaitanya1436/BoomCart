import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Package, 
  ShoppingBag, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Loader2,
  ArrowRight,
  Calendar
} from "lucide-react";
import LoginModal from "@/components/LoginModal";
import { Order, OrderItem, Product } from "@shared/schema";

type OrderWithItems = Order & { 
  items: (OrderItem & { product: Product })[] 
};

const OrderTracking = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<OrderWithItems | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Fetch orders when authenticated
  useEffect(() => {
    const fetchOrders = async () => {
      if (!isAuthenticated) {
        setIsLoading(false);
        return;
      }
      
      try {
        const response = await fetch("/api/orders", {
          credentials: "include",
        });
        
        if (!response.ok) {
          throw new Error("Failed to fetch orders");
        }
        
        const data = await response.json();
        setOrders(data);
      } catch (error) {
        console.error("Error fetching orders:", error);
        toast({
          title: "Failed to load orders",
          variant: "destructive",
          duration: 3000,
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchOrders();
  }, [isAuthenticated, toast]);
  
  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      setLoginModalOpen(true);
    }
  }, [isAuthenticated, isLoading]);
  
  const fetchOrderDetails = async (orderId: number) => {
    if (selectedOrder?.id === orderId) {
      setSelectedOrder(null);
      return;
    }
    
    setIsLoadingDetails(true);
    
    try {
      const response = await fetch(`/api/orders/${orderId}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch order details");
      }
      
      const data = await response.json();
      setSelectedOrder(data);
    } catch (error) {
      console.error("Error fetching order details:", error);
      toast({
        title: "Failed to load order details",
        variant: "destructive",
        duration: 3000,
      });
    } finally {
      setIsLoadingDetails(false);
    }
  };
  
  // Format price in cents to dollars
  const formatPrice = (price: number) => {
    return (price / 100).toFixed(2);
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };
  
  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "completed":
        return "bg-green-600";
      case "processing":
        return "bg-blue-600";
      case "pending":
        return "bg-yellow-600";
      case "cancelled":
        return "bg-red-600";
      default:
        return "bg-gray-600";
    }
  };
  
  // Get status icon
  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "completed":
        return <CheckCircle2 className="h-4 w-4" />;
      case "processing":
        return <Clock className="h-4 w-4" />;
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "cancelled":
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };
  
  if (!isAuthenticated && !isLoading) {
    return <LoginModal isOpen={loginModalOpen} onClose={() => navigate("/")} />;
  }
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center">
        <Loader2 className="h-12 w-12 text-accent animate-spin" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">My Orders</h1>
      
      {orders.length === 0 ? (
        <div className="text-center py-12">
          <div className="bg-gray-800 rounded-full p-6 inline-block mb-6">
            <Package className="h-12 w-12 text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold mb-3">No orders yet</h2>
          <p className="text-gray-400 mb-6">You haven't placed any orders yet. Start shopping to see your orders here.</p>
          <Link href="/category/all">
            <Button className="bg-accent hover:bg-accent/90">
              Start Shopping
            </Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-6">
          {orders.map((order) => (
            <Card key={order.id} className="bg-gray-900 border-gray-800">
              <CardHeader className="pb-3">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ShoppingBag className="h-5 w-5 text-accent" />
                      Order #{order.id}
                    </CardTitle>
                    <div className="flex items-center gap-2 mt-1 text-sm text-gray-400">
                      <Calendar className="h-4 w-4" />
                      <span>{order.createdAt ? formatDate(order.createdAt) : "N/A"}</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-4">
                    <Badge className={`${getStatusColor(order.status)} flex items-center gap-1`}>
                      {getStatusIcon(order.status)}
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </Badge>
                    <span className="font-bold text-white">${formatPrice(order.total)}</span>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="border-accent text-accent hover:bg-accent/10"
                      onClick={() => fetchOrderDetails(order.id)}
                      disabled={isLoadingDetails}
                    >
                      {isLoadingDetails && selectedOrder?.id === order.id ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : selectedOrder?.id === order.id ? (
                        "Hide Details"
                      ) : (
                        <>
                          View Details
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              {selectedOrder?.id === order.id && (
                <CardContent>
                  <Accordion type="single" collapsible defaultValue="items">
                    <AccordionItem value="items" className="border-gray-800">
                      <AccordionTrigger className="text-white">
                        Order Items
                      </AccordionTrigger>
                      <AccordionContent>
                        <Table>
                          <TableHeader className="bg-gray-800">
                            <TableRow className="border-gray-700">
                              <TableHead className="text-gray-300">Product</TableHead>
                              <TableHead className="text-gray-300 text-right">Price</TableHead>
                              <TableHead className="text-gray-300 text-center">Quantity</TableHead>
                              <TableHead className="text-gray-300 text-right">Total</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedOrder.items.map((item) => (
                              <TableRow key={item.id} className="border-gray-800">
                                <TableCell>
                                  <Link href={`/product/${item.productId}`}>
                                    <div className="flex items-center space-x-4">
                                      <div className="h-12 w-12 bg-gray-800 rounded"></div>
                                      <div className="font-medium underline">{item.product.name}</div>
                                    </div>
                                  </Link>
                                </TableCell>
                                <TableCell className="text-right">
                                  ${formatPrice(item.price)}
                                </TableCell>
                                <TableCell className="text-center">
                                  {item.quantity}
                                </TableCell>
                                <TableCell className="text-right font-medium">
                                  ${formatPrice(item.price * item.quantity)}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </AccordionContent>
                    </AccordionItem>
                    
                    <AccordionItem value="shipping" className="border-gray-800">
                      <AccordionTrigger className="text-white">
                        Shipping Details
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="bg-gray-800 p-4 rounded-md">
                          <p className="text-gray-300">{selectedOrder.shippingAddress}</p>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                    
                    <AccordionItem value="payment" className="border-gray-800">
                      <AccordionTrigger className="text-white">
                        Payment Information
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="bg-gray-800 p-4 rounded-md space-y-3">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Payment Method:</span>
                            <span>{selectedOrder.paymentMethod}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Subtotal:</span>
                            <span>${formatPrice(selectedOrder.total - 1099)}</span> {/* Approximate subtotal */}
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Shipping:</span>
                            <span>$5.99</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Tax:</span>
                            <span>$5.00</span> {/* Approximate tax */}
                          </div>
                          <div className="flex justify-between font-bold">
                            <span>Total:</span>
                            <span>${formatPrice(selectedOrder.total)}</span>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default OrderTracking;
