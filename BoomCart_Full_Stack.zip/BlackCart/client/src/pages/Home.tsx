import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight, Lock } from "lucide-react";
import ProductGrid from "@/components/ProductGrid";
import { Product, Category } from "@shared/schema";

const Home = () => {
  const [trendingProducts, setTrendingProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [productsRes, categoriesRes] = await Promise.all([
          fetch('/api/products/trending?limit=4'),
          fetch('/api/categories')
        ]);
        
        const products = await productsRes.json();
        const categories = await categoriesRes.json();
        
        setTrendingProducts(products);
        setCategories(categories);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  // Filter unlocked and locked categories
  const unlockedCategories = categories.filter(c => !c.isLocked);
  const lockedCategories = categories.filter(c => c.isLocked);
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Hero Banner */}
      <section className="relative w-full h-64 md:h-96 rounded-xl overflow-hidden mb-8 bg-gradient-to-r from-gray-900 to-gray-800">
        <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col justify-center items-start p-8">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Summer Collection <span className="text-accent">2023</span>
          </h2>
          <p className="text-lg text-gray-200 mb-6 max-w-lg">
            Discover our latest arrivals with styles that define the season
          </p>
          <Button className="bg-accent hover:bg-accent/90 text-white px-6 py-3 rounded-md font-medium">
            Shop Now
          </Button>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Shop By Category</h2>
          <Link href="/category/all" className="text-accent hover:underline">
            View All
          </Link>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {isLoading ? (
            // Loading placeholders
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-40 md:h-60 rounded-lg bg-gray-800 animate-pulse"></div>
            ))
          ) : (
            // Render all categories
            categories.map(category => (
              <div 
                key={category.id} 
                className="product-card relative h-40 md:h-60 rounded-lg overflow-hidden bg-gray-900 group"
              >
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-4">
                  <h3 className="text-lg font-medium text-white">{category.name}</h3>
                  <p className="text-sm text-gray-300 mt-1">
                    {category.productCount > 0 
                      ? `${category.productCount}+ Products` 
                      : category.isLocked 
                        ? "Locked" 
                        : "Coming Soon"
                    }
                  </p>
                </div>
                
                {category.isLocked && (
                  <div className="absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center">
                    <div className="text-center">
                      <Lock className="h-8 w-8 text-accent mx-auto mb-2" />
                      <p className="text-white text-sm px-4">{category.message}</p>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </section>

      {/* Trending Products */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Trending Products</h2>
          <Link href="/category/all" className="text-accent hover:underline">
            View All
          </Link>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="bg-gray-800 rounded-lg animate-pulse">
                <div className="h-48 bg-gray-700"></div>
                <div className="p-4">
                  <div className="h-4 bg-gray-700 rounded w-1/2 mb-2"></div>
                  <div className="h-5 bg-gray-700 rounded w-3/4 mb-3"></div>
                  <div className="h-4 bg-gray-700 rounded w-1/4 mb-4"></div>
                  <div className="flex justify-between">
                    <div className="h-6 bg-gray-700 rounded w-1/4"></div>
                    <div className="h-8 w-8 bg-gray-700 rounded-full"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <ProductGrid initialProducts={trendingProducts} isHomePage />
        )}
      </section>

      {/* Special Offers */}
      <section className="mb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gradient-to-r from-purple-900 to-purple-700 rounded-xl p-6 flex flex-col justify-between min-h-[200px]">
            <div>
              <span className="inline-block px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm mb-4">
                Limited Time
              </span>
              <h3 className="text-2xl font-bold mb-2">Summer Collection</h3>
              <p className="text-gray-200 mb-4">Get up to 50% off on selected items</p>
            </div>
            <Link href="/category/Clothes">
              <Button className="bg-white text-purple-900 hover:bg-white/90 px-5 py-2 rounded-md font-medium w-max">
                Shop Now
              </Button>
            </Link>
          </div>
          
          <div className="bg-gradient-to-r from-gray-900 to-gray-700 rounded-xl p-6 flex flex-col justify-between min-h-[200px]">
            <div>
              <span className="inline-block px-3 py-1 bg-white bg-opacity-20 rounded-full text-sm mb-4">
                New Arrivals
              </span>
              <h3 className="text-2xl font-bold mb-2">Beauty Essentials</h3>
              <p className="text-gray-200 mb-4">Discover our premium skincare collection</p>
            </div>
            <Link href="/category/Beauty & Personal Care">
              <Button className="bg-white text-gray-900 hover:bg-white/90 px-5 py-2 rounded-md font-medium w-max">
                Shop Now
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Popular Brands */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Popular Brands</h2>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-20 bg-gray-900 rounded-lg flex items-center justify-center">
              <span className="text-gray-400 font-medium">Brand {i + 1}</span>
            </div>
          ))}
        </div>
      </section>
      
      {/* Browse Products Preview */}
      <section className="bg-gray-900 py-12 -mx-4 px-4 mt-8">
        <div className="container mx-auto">
          <h2 className="text-2xl font-bold mb-8">Browse Products</h2>
          
          {/* Products Grid Preview */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="bg-gray-800 rounded-lg animate-pulse">
                  <div className="h-48 bg-gray-700"></div>
                  <div className="p-4">
                    <div className="h-4 bg-gray-700 rounded w-1/2 mb-2"></div>
                    <div className="h-5 bg-gray-700 rounded w-3/4 mb-3"></div>
                    <div className="h-4 bg-gray-700 rounded w-1/4 mb-4"></div>
                    <div className="flex justify-between">
                      <div className="h-6 bg-gray-700 rounded w-1/4"></div>
                      <div className="h-8 w-8 bg-gray-700 rounded-full"></div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              // This would typically be a different set of products from the API
              trendingProducts.slice(0, 5).map(product => (
                <ProductCard key={product.id} product={product} />
              ))
            )}
          </div>
          
          {/* Load More / Infinite Scroll Indicator */}
          <div className="flex justify-center mt-8">
            <Link href="/category/all">
              <div className="text-center cursor-pointer">
                <div className="bounce mb-2">
                  <ChevronRight className="transform rotate-90 text-accent" />
                </div>
                <p className="text-sm text-gray-400">Browse more products</p>
              </div>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Locked Sections */}
      <section className="container mx-auto py-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Coming Soon</h2>
          <div className="flex items-center text-sm text-accent">
            <span className="mr-1">Become a Sponsor</span>
            <ChevronRight className="h-4 w-4" />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {lockedCategories.map(category => (
            <div 
              key={category.id} 
              className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl overflow-hidden shadow-xl relative group"
            >
              {/* Top part with category name */}
              <div className="p-6 border-b border-gray-800">
                <h3 className="text-xl font-bold mb-1">{category.name}</h3>
                <p className="text-gray-400 text-sm">Coming Soon</p>
              </div>
              
              {/* Bottom part with locked message */}
              <div className="px-6 py-10 flex items-center justify-center min-h-[180px] relative">
                {/* Background pattern */}
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute -right-10 -bottom-10 w-40 h-40 rounded-full bg-accent opacity-20"></div>
                  <div className="absolute -left-10 -top-10 w-40 h-40 rounded-full bg-accent opacity-10"></div>
                </div>
                
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                
                {/* Lock icon and message */}
                <div className="bg-black/40 backdrop-blur-sm p-6 rounded-xl border border-gray-700/40 relative z-10 w-full max-w-md transform transition-transform duration-300 group-hover:scale-105">
                  <div className="flex items-center mb-4">
                    <div className="p-3 bg-accent/20 rounded-full mr-4">
                      <Lock className="text-accent h-6 w-6" />
                    </div>
                    <h4 className="font-bold text-lg">Sponsor Opportunity</h4>
                  </div>
                  
                  <p className="text-gray-300 mb-4">
                    {category.message || "No sponsors yet... To sponsor, please mail us."}
                  </p>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-400">Limited slots available</span>
                    <button className="text-accent text-sm font-medium hover:underline transition">
                      Contact Us
                    </button>
                  </div>
                </div>
              </div>
              
              {/* Ribbon effect */}
              <div className="absolute top-4 right-0 bg-accent text-white text-xs font-bold py-1 px-3 shadow-lg transform skew-x-12 after:content-[''] after:absolute after:top-0 after:right-0 after:w-3 after:h-full after:bg-accent/50 after:-z-10">
                LOCKED
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

// Helper component for the preview section
const ProductCard = ({ product }: { product: Product }) => {
  return (
    <Link href={`/product/${product.id}`}>
      <div className="product-card bg-gray-800 rounded-lg overflow-hidden cursor-pointer">
        <div className="h-48 bg-gray-700 relative">
          {product.isNew && (
            <div className="absolute top-2 right-2 bg-green-600 text-white text-xs py-1 px-2 rounded">
              NEW
            </div>
          )}
          
          {product.discountPrice && (
            <div className="absolute top-2 right-2 bg-accent text-white text-xs py-1 px-2 rounded">
              -{Math.round((1 - (product.price / product.discountPrice)) * 100)}%
            </div>
          )}
        </div>
        
        <div className="p-4">
          <h3 className="text-sm text-gray-400">{product.subcategory}</h3>
          <p className="font-medium mt-1 text-sm md:text-base">{product.name}</p>
          
          <div className="flex items-center mt-2">
            <div className="text-yellow-400 text-xs">
              {Array(Math.floor(product.rating || 0)).fill(null).map((_, i) => (
                <span key={i}>★</span>
              ))}
              {(product.rating || 0) % 1 >= 0.5 && <span>★</span>}
              {Array(5 - Math.ceil(product.rating || 0)).fill(null).map((_, i) => (
                <span key={i} className="text-gray-500">★</span>
              ))}
            </div>
            <span className="text-xs text-gray-400 ml-1">({product.reviewCount})</span>
          </div>
          
          <div className="flex justify-between items-center mt-3">
            <div>
              <span className="text-accent font-bold text-sm md:text-base">
                ${(product.price / 100).toFixed(2)}
              </span>
              {product.discountPrice && (
                <span className="text-gray-400 text-sm line-through ml-2">
                  ${(product.discountPrice / 100).toFixed(2)}
                </span>
              )}
            </div>
            
            <button className="p-2 bg-accent rounded-full text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14" /><path d="M12 5v14" /></svg>
            </button>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default Home;
