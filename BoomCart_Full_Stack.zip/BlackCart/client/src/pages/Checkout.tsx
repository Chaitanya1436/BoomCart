import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import PaymentForm from "@/components/PaymentForm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ShoppingBag, MapPin, CreditCard, Truck, Check } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { formatPrice } from "@/lib/utils";

enum CheckoutStep {
  SHIPPING = "shipping",
  PAYMENT = "payment",
  CONFIRMATION = "confirmation",
}

interface ShippingInfo {
  fullName: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
}

const Checkout = () => {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const { cartItems, getCartTotal, clearCart } = useCart();
  const { user, isAuthenticated } = useAuth();
  const [currentStep, setCurrentStep] = useState<CheckoutStep>(CheckoutStep.SHIPPING);
  const [paymentProcessed, setPaymentProcessed] = useState(false);
  const [transactionId, setTransactionId] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [shippingInfo, setShippingInfo] = useState<ShippingInfo>({
    fullName: user?.displayName || "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    phone: "",
  });
  
  // Redirect if not authenticated or cart is empty
  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please login to continue with checkout",
        variant: "destructive",
      });
      setLocation("/");
      return;
    }
    
    if (cartItems.length === 0) {
      toast({
        title: "Empty Cart",
        description: "Your cart is empty. Add some products before checkout.",
        variant: "destructive",
      });
      setLocation("/");
      return;
    }
  }, [isAuthenticated, cartItems.length, setLocation, toast]);
  
  const handleShippingInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setShippingInfo((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  
  const validateShippingInfo = () => {
    const { fullName, address, city, state, pincode, phone } = shippingInfo;
    if (!fullName || !address || !city || !state || !pincode || !phone) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return false;
    }
    
    // Validate Indian phone number (10 digits)
    if (!/^[6-9]\d{9}$/.test(phone)) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid 10-digit Indian phone number",
        variant: "destructive",
      });
      return false;
    }
    
    // Validate Indian pincode (6 digits)
    if (!/^\d{6}$/.test(pincode)) {
      toast({
        title: "Invalid Pincode",
        description: "Please enter a valid 6-digit pincode",
        variant: "destructive",
      });
      return false;
    }
    
    return true;
  };
  
  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateShippingInfo()) {
      setCurrentStep(CheckoutStep.PAYMENT);
    }
  };
  
  const handlePaymentComplete = async (transactionId: string, paymentMethod: string) => {
    setTransactionId(transactionId);
    setPaymentProcessed(true);
    setIsSubmitting(true);
    
    try {
      // Create order with API
      const orderData = {
        userId: user?.id,
        shippingAddress: `${shippingInfo.fullName}, ${shippingInfo.address}, ${shippingInfo.city}, ${shippingInfo.state} - ${shippingInfo.pincode}, Phone: ${shippingInfo.phone}`,
        paymentMethod: "UPI",
        transactionId,
        status: "pending_verification", // Pending manual verification
        total: getCartTotal(),
        items: cartItems.map(item => ({
          productId: item.productId,
          quantity: item.quantity,
          price: item.product.price,
          name: item.product.name
        }))
      };
      
      const response = await apiRequest("POST", "/api/orders", orderData);
      
      if (response.ok) {
        // Send email notification (handled server-side)
        await apiRequest("POST", "/api/notify/order", {
          email: "sayboomcart@gmail.com",
          orderData: {
            ...orderData,
            customerEmail: user?.email,
            customerName: shippingInfo.fullName,
            totalItems: getTotalItems(),
            formattedTotal: formatPrice(getCartTotal()),
            orderDate: new Date().toISOString()
          }
        });
        
        // Clear cart after successful order
        await clearCart();
        setCurrentStep(CheckoutStep.CONFIRMATION);
        toast({
          title: "Order Placed Successfully",
          description: "Your order has been received and is pending verification",
        });
      } else {
        throw new Error("Failed to place order");
      }
    } catch (error) {
      console.error("Order placement error:", error);
      toast({
        title: "Order Failed",
        description: "There was an error processing your order. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const getTotalItems = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };
  
  if (cartItems.length === 0 && currentStep !== CheckoutStep.CONFIRMATION) {
    return (
      <div className="container max-w-4xl mx-auto py-16 px-4 text-center">
        <h1 className="text-2xl font-bold mb-4">Your cart is empty</h1>
        <p className="mb-6">Add some products to your cart before proceeding to checkout.</p>
        <Button onClick={() => setLocation("/")}>Continue Shopping</Button>
      </div>
    );
  }
  
  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Checkout</h1>
      
      {/* Checkout Steps Indicator */}
      <div className="flex justify-between mb-8 relative">
        <div className="w-full absolute top-1/2 h-1 bg-gray-600" />
        
        <div className={`relative flex flex-col items-center ${currentStep === CheckoutStep.SHIPPING ? 'text-orange-500' : (currentStep === CheckoutStep.PAYMENT || currentStep === CheckoutStep.CONFIRMATION) ? 'text-green-500' : 'text-gray-400'}`}>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center z-10 ${currentStep === CheckoutStep.SHIPPING ? 'bg-orange-500 text-white' : (currentStep === CheckoutStep.PAYMENT || currentStep === CheckoutStep.CONFIRMATION) ? 'bg-green-500 text-white' : 'bg-gray-700 text-gray-400'}`}>
            {currentStep === CheckoutStep.SHIPPING ? <MapPin size={18} /> : <Check size={18} />}
          </div>
          <span className="mt-2 font-medium">Shipping</span>
        </div>
        
        <div className={`relative flex flex-col items-center ${currentStep === CheckoutStep.PAYMENT ? 'text-orange-500' : currentStep === CheckoutStep.CONFIRMATION ? 'text-green-500' : 'text-gray-400'}`}>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center z-10 ${currentStep === CheckoutStep.PAYMENT ? 'bg-orange-500 text-white' : currentStep === CheckoutStep.CONFIRMATION ? 'bg-green-500 text-white' : 'bg-gray-700 text-gray-400'}`}>
            {currentStep === CheckoutStep.PAYMENT && !paymentProcessed ? <CreditCard size={18} /> : currentStep === CheckoutStep.CONFIRMATION || paymentProcessed ? <Check size={18} /> : <CreditCard size={18} />}
          </div>
          <span className="mt-2 font-medium">Payment</span>
        </div>
        
        <div className={`relative flex flex-col items-center ${currentStep === CheckoutStep.CONFIRMATION ? 'text-green-500' : 'text-gray-400'}`}>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center z-10 ${currentStep === CheckoutStep.CONFIRMATION ? 'bg-green-500 text-white' : 'bg-gray-700 text-gray-400'}`}>
            {currentStep === CheckoutStep.CONFIRMATION ? <Check size={18} /> : <Truck size={18} />}
          </div>
          <span className="mt-2 font-medium">Confirmation</span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* Shipping Information Form */}
          {currentStep === CheckoutStep.SHIPPING && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Shipping Information</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleShippingSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        name="fullName"
                        value={shippingInfo.fullName}
                        onChange={handleShippingInfoChange}
                        placeholder="Enter your full name"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={shippingInfo.phone}
                        onChange={handleShippingInfoChange}
                        placeholder="10-digit mobile number"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <Label htmlFor="address">Address</Label>
                    <Textarea
                      id="address"
                      name="address"
                      value={shippingInfo.address}
                      onChange={handleShippingInfoChange}
                      placeholder="Street address, apartment, etc."
                      rows={3}
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        name="city"
                        value={shippingInfo.city}
                        onChange={handleShippingInfoChange}
                        placeholder="City"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="state">State</Label>
                      <Input
                        id="state"
                        name="state"
                        value={shippingInfo.state}
                        onChange={handleShippingInfoChange}
                        placeholder="State"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="pincode">Pincode</Label>
                      <Input
                        id="pincode"
                        name="pincode"
                        value={shippingInfo.pincode}
                        onChange={handleShippingInfoChange}
                        placeholder="6-digit pincode"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <Button 
                      type="submit"
                      className="w-full bg-orange-500 hover:bg-orange-600"
                    >
                      Continue to Payment
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}
          
          {/* Payment Form */}
          {currentStep === CheckoutStep.PAYMENT && (
            <PaymentForm
              totalAmount={getCartTotal() / 100}
              onPaymentComplete={handlePaymentComplete}
              onCancel={() => setCurrentStep(CheckoutStep.SHIPPING)}
            />
          )}
          
          {/* Order Confirmation */}
          {currentStep === CheckoutStep.CONFIRMATION && (
            <Card>
              <CardHeader className="text-center border-b border-gray-700 pb-6">
                <div className="w-16 h-16 bg-green-100 rounded-full mx-auto flex items-center justify-center mb-4">
                  <Check className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle className="text-2xl font-bold">Order Confirmed!</CardTitle>
                <p className="text-gray-400 mt-2">
                  Your order has been placed and is pending verification
                </p>
              </CardHeader>
              
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Order Details</h3>
                    <p className="text-gray-400">Transaction ID: {transactionId}</p>
                    <p className="text-gray-400">Order Status: Pending Verification</p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-lg font-medium mb-2">Shipping Address</h3>
                    <p className="text-gray-400">{shippingInfo.fullName}</p>
                    <p className="text-gray-400">{shippingInfo.address}</p>
                    <p className="text-gray-400">
                      {shippingInfo.city}, {shippingInfo.state} - {shippingInfo.pincode}
                    </p>
                    <p className="text-gray-400">Phone: {shippingInfo.phone}</p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-lg font-medium mb-2">Payment Information</h3>
                    <p className="text-gray-400">Method: UPI</p>
                    <p className="text-gray-400">Status: Pending Verification</p>
                  </div>
                </div>
                
                <div className="mt-8 text-center">
                  <p className="mb-4 text-gray-400">
                    Your payment is pending verification. You can track your order status in the My Orders section.
                  </p>
                  <Button 
                    onClick={() => setLocation("/orders")}
                    className="bg-orange-500 hover:bg-orange-600 mr-2"
                  >
                    View My Orders
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => setLocation("/")}
                  >
                    Continue Shopping
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        
        {/* Order Summary */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex items-center space-x-4">
                    <div className="w-16 h-16 bg-gray-700 rounded overflow-hidden flex items-center justify-center">
                      {item.product.imageUrl ? (
                        <img 
                          src={item.product.imageUrl} 
                          alt={item.product.name} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <ShoppingBag className="w-8 h-8 text-gray-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{item.product.name}</p>
                      <p className="text-sm text-gray-400">Qty: {item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">
                        {formatPrice((item.product.discountPrice || item.product.price) * item.quantity)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              
              <Separator className="my-4" />
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400">Subtotal ({getTotalItems()} items)</span>
                  <span>{formatPrice(getCartTotal())}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Shipping</span>
                  <span>Free</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Tax</span>
                  <span>Included</span>
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>{formatPrice(getCartTotal())}</span>
              </div>
            </CardContent>
            
            <CardFooter>
              {currentStep !== CheckoutStep.CONFIRMATION && (
                <div className="w-full text-center text-sm text-gray-400">
                  <p>
                    By proceeding, you agree to our{" "}
                    <a href="/terms-of-service" className="text-orange-500 hover:text-orange-600">Terms of Service</a>
                    {" "}and{" "}
                    <a href="/privacy-policy" className="text-orange-500 hover:text-orange-600">Privacy Policy</a>
                  </p>
                </div>
              )}
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Checkout;