import { 
  users, type User, type InsertUser,
  products, type Product, type InsertProduct,
  cartItems, type CartItem, type InsertCartItem,
  wishlistItems, type WishlistItem, type InsertWishlistItem,
  orders, type Order, type InsertOrder,
  orderItems, type OrderItem, type InsertOrderItem,
  categories, type Category, type InsertCategory,
  discountCoupons, type DiscountCoupon, type InsertDiscountCoupon
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Product operations
  getProducts(category?: string, limit?: number, offset?: number): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getTrendingProducts(limit?: number): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  filterProducts(filters: ProductFilters): Promise<Product[]>;
  
  // Cart operations
  getCartItems(userId: number): Promise<(CartItem & { product: Product })[]>;
  addToCart(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(id: number): Promise<boolean>;
  clearCart(userId: number): Promise<boolean>;
  
  // Wishlist operations
  getWishlistItems(userId: number): Promise<(WishlistItem & { product: Product })[]>;
  addToWishlist(wishlistItem: InsertWishlistItem): Promise<WishlistItem>;
  removeWishlistItem(id: number): Promise<boolean>;
  
  // Order operations
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  getOrderById(id: number): Promise<(Order & { items: (OrderItem & { product: Product })[] }) | undefined>;
  getAllOrders(): Promise<Order[]>; // Admin function to get all orders
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>; // Admin function to update order status
  verifyOrderPayment(id: number, status: string, notes?: string): Promise<Order | undefined>; // Admin function to verify payment
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategoryByName(name: string): Promise<Category | undefined>;
  
  // Discount Coupon operations
  getDiscountCoupon(code: string): Promise<DiscountCoupon | undefined>;
  createDiscountCoupon(coupon: InsertDiscountCoupon): Promise<DiscountCoupon>;
  updateDiscountCoupon(id: number, updates: Partial<InsertDiscountCoupon>): Promise<DiscountCoupon | undefined>;
  deleteDiscountCoupon(id: number): Promise<boolean>;
  getAllDiscountCoupons(): Promise<DiscountCoupon[]>;
  validateCoupon(code: string): Promise<{isValid: boolean; discount?: number; message?: string}>;
  
  // Database operations
  initializeDatabase(): Promise<void>;
}

export type ProductFilters = {
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  brand?: string[];
  rating?: number;
  inStock?: boolean;
  size?: string[];
  color?: string[];
  search?: string;
  sort?: 'price_asc' | 'price_desc' | 'newest' | 'rating';
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private wishlistItems: Map<number, WishlistItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private categories: Map<number, Category>;
  private discountCoupons: Map<number, DiscountCoupon>;
  
  private currentUserId: number;
  private currentProductId: number;
  private currentCartItemId: number;
  private currentWishlistItemId: number;
  private currentOrderId: number;
  private currentOrderItemId: number;
  private currentCategoryId: number;
  private currentDiscountCouponId: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.wishlistItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.categories = new Map();
    this.discountCoupons = new Map();
    
    this.currentUserId = 1;
    this.currentProductId = 1;
    this.currentCartItemId = 1;
    this.currentWishlistItemId = 1;
    this.currentOrderId = 1;
    this.currentOrderItemId = 1;
    this.currentCategoryId = 1;
    this.currentDiscountCouponId = 1;
    
    // Initialize categories
    this.initializeCategories();
    
    // Initialize sample products
    this.initializeProducts();
  }
  
  async initializeDatabase(): Promise<void> {
    // Memory storage is already initialized in the constructor
    return Promise.resolve();
  }
  
  private initializeCategories() {
    const categoriesData: InsertCategory[] = [
      {
        name: "Clothes",
        isLocked: false,
        imageUrl: "",
        productCount: 65
      },
      {
        name: "Beauty & Personal Care",
        isLocked: false,
        imageUrl: "",
        productCount: 48
      },
      {
        name: "Section 1",
        isLocked: true,
        message: "No sponsors yet... To sponsor, please mail us.",
        imageUrl: "",
        productCount: 0
      },
      {
        name: "Section 2",
        isLocked: true,
        message: "No sponsors yet... To sponsor, please mail us.",
        imageUrl: "",
        productCount: 0
      },
      {
        name: "Section 3",
        isLocked: true,
        message: "No sponsors yet... To sponsor, please mail us.",
        imageUrl: "",
        productCount: 0
      }
    ];
    
    categoriesData.forEach(category => {
      const id = this.currentCategoryId++;
      this.categories.set(id, { ...category, id });
    });
  }
  
  private initializeProducts() {
    const productData: InsertProduct[] = [
      {
        name: "Casual Slim Fit T-Shirt",
        description: "A comfortable, slim-fit t-shirt perfect for casual wear.",
        price: 2499, // $24.99
        discountPrice: 2999, // $29.99
        category: "Clothes",
        subcategory: "Men's Fashion",
        imageUrl: "",
        rating: 4,
        reviewCount: 42,
        isNew: false,
        inStock: true,
        brand: "Brand 1",
        size: "M",
        color: "Blue",
        trending: true
      },
      {
        name: "Bohemian Maxi Dress",
        description: "A beautiful bohemian style maxi dress for summer occasions.",
        price: 4999, // $49.99
        category: "Clothes",
        subcategory: "Women's Fashion",
        imageUrl: "",
        rating: 5,
        reviewCount: 78,
        isNew: false,
        inStock: true,
        brand: "Brand 2",
        size: "M",
        color: "Floral",
        trending: true
      },
      {
        name: "Vitamin C Serum",
        description: "High potency vitamin C serum for brighter, healthier skin.",
        price: 3499, // $34.99
        category: "Beauty & Personal Care",
        subcategory: "Skincare",
        imageUrl: "",
        rating: 5,
        reviewCount: 124,
        isNew: true,
        inStock: true,
        brand: "Brand 3",
        trending: true
      },
      {
        name: "Electric Shaver Pro",
        description: "Advanced electric shaver with multiple settings for a clean shave.",
        price: 7999, // $79.99
        discountPrice: 9999, // $99.99
        category: "Beauty & Personal Care",
        subcategory: "Personal Care",
        imageUrl: "",
        rating: 4,
        reviewCount: 56,
        isNew: false,
        inStock: true,
        brand: "Brand 4",
        trending: true
      },
      {
        name: "Denim Jacket Blue",
        description: "Classic denim jacket, perfect for layering in any season.",
        price: 5999, // $59.99
        category: "Clothes",
        subcategory: "Men's Fashion",
        imageUrl: "",
        rating: 4,
        reviewCount: 28,
        isNew: false,
        inStock: true,
        brand: "Brand 1",
        size: "L",
        color: "Blue",
        trending: false
      },
      {
        name: "Summer Floral Dress",
        description: "Light and airy floral dress, perfect for summer days.",
        price: 4250, // $42.50
        discountPrice: 5000, // $50.00
        category: "Clothes",
        subcategory: "Women's Fashion",
        imageUrl: "",
        rating: 4,
        reviewCount: 47,
        isNew: false,
        inStock: true,
        brand: "Brand 5",
        size: "S",
        color: "Floral",
        trending: false
      },
      {
        name: "Facial Cleanser",
        description: "Gentle facial cleanser that removes dirt and makeup without drying skin.",
        price: 2299, // $22.99
        category: "Beauty & Personal Care",
        subcategory: "Skincare",
        imageUrl: "",
        rating: 5,
        reviewCount: 112,
        isNew: false,
        inStock: true,
        brand: "Brand 3",
        trending: false
      },
      {
        name: "Hair Dryer Pro",
        description: "Professional-grade hair dryer with multiple heat and speed settings.",
        price: 8999, // $89.99
        category: "Beauty & Personal Care",
        subcategory: "Personal Care",
        imageUrl: "",
        rating: 4,
        reviewCount: 34,
        isNew: true,
        inStock: true,
        brand: "Brand 6",
        trending: false
      },
      {
        name: "Classic Watch",
        description: "Timeless classic watch with leather band, suitable for any occasion.",
        price: 12999, // $129.99
        category: "Clothes",
        subcategory: "Men's Fashion",
        imageUrl: "",
        rating: 5,
        reviewCount: 86,
        isNew: false,
        inStock: true,
        brand: "Brand 2",
        color: "Brown",
        trending: false
      }
    ];
    
    // Generate 91 more products to reach 100 total
    for (let i = 0; i < 91; i++) {
      const categoryIndex = i % 2;
      const categoryName = categoryIndex === 0 ? "Clothes" : "Beauty & Personal Care";
      const subcategoryIndex = i % 4;
      let subcategory = "";
      
      if (categoryName === "Clothes") {
        subcategory = subcategoryIndex < 2 ? "Men's Fashion" : "Women's Fashion";
      } else {
        subcategory = subcategoryIndex < 2 ? "Skincare" : "Personal Care";
      }
      
      productData.push({
        name: `Product ${i + 10}`,
        description: `Description for product ${i + 10}`,
        price: 1000 + (i * 100), // Price varies from $10 to $100
        category: categoryName,
        subcategory,
        imageUrl: "",
        rating: Math.floor(Math.random() * 5) + 1, // Random rating 1-5
        reviewCount: Math.floor(Math.random() * 100),
        isNew: i % 10 === 0, // Every 10th product is new
        inStock: true,
        brand: `Brand ${(i % 6) + 1}`,
        trending: false
      });
    }
    
    productData.forEach(product => {
      const id = this.currentProductId++;
      this.products.set(id, { ...product, id });
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.googleId === googleId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, isAdmin: false };
    this.users.set(id, user);
    return user;
  }

  // Product operations
  async getProducts(category?: string, limit = 20, offset = 0): Promise<Product[]> {
    let products = Array.from(this.products.values());
    
    if (category) {
      products = products.filter(product => 
        product.category === category || product.subcategory === category
      );
    }
    
    return products.slice(offset, offset + limit);
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getTrendingProducts(limit = 4): Promise<Product[]> {
    return Array.from(this.products.values())
      .filter(product => product.trending)
      .slice(0, limit);
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(product => 
      product.name.toLowerCase().includes(lowercaseQuery) ||
      product.description.toLowerCase().includes(lowercaseQuery) ||
      product.category.toLowerCase().includes(lowercaseQuery) ||
      (product.subcategory && product.subcategory.toLowerCase().includes(lowercaseQuery)) ||
      (product.brand && product.brand.toLowerCase().includes(lowercaseQuery))
    );
  }

  async filterProducts(filters: ProductFilters): Promise<Product[]> {
    let filteredProducts = Array.from(this.products.values());
    
    if (filters.category) {
      filteredProducts = filteredProducts.filter(product => 
        product.category === filters.category || product.subcategory === filters.category
      );
    }
    
    if (filters.minPrice !== undefined) {
      filteredProducts = filteredProducts.filter(product => 
        product.price >= filters.minPrice!
      );
    }
    
    if (filters.maxPrice !== undefined) {
      filteredProducts = filteredProducts.filter(product => 
        product.price <= filters.maxPrice!
      );
    }
    
    if (filters.brand && filters.brand.length > 0) {
      filteredProducts = filteredProducts.filter(product => 
        product.brand && filters.brand!.includes(product.brand)
      );
    }
    
    if (filters.rating !== undefined) {
      filteredProducts = filteredProducts.filter(product => 
        product.rating && product.rating >= filters.rating!
      );
    }
    
    if (filters.inStock !== undefined) {
      filteredProducts = filteredProducts.filter(product => 
        product.inStock === filters.inStock
      );
    }
    
    if (filters.size && filters.size.length > 0) {
      filteredProducts = filteredProducts.filter(product => 
        product.size && filters.size!.includes(product.size)
      );
    }
    
    if (filters.color && filters.color.length > 0) {
      filteredProducts = filteredProducts.filter(product => 
        product.color && filters.color!.includes(product.color)
      );
    }
    
    if (filters.search) {
      const lowercaseSearch = filters.search.toLowerCase();
      filteredProducts = filteredProducts.filter(product => 
        product.name.toLowerCase().includes(lowercaseSearch) ||
        product.description.toLowerCase().includes(lowercaseSearch) ||
        (product.brand && product.brand.toLowerCase().includes(lowercaseSearch))
      );
    }
    
    // Sorting
    if (filters.sort) {
      switch (filters.sort) {
        case 'price_asc':
          filteredProducts.sort((a, b) => a.price - b.price);
          break;
        case 'price_desc':
          filteredProducts.sort((a, b) => b.price - a.price);
          break;
        case 'rating':
          filteredProducts.sort((a, b) => (b.rating || 0) - (a.rating || 0));
          break;
        case 'newest':
          filteredProducts.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
          break;
      }
    }
    
    return filteredProducts;
  }

  // Cart operations
  async getCartItems(userId: number): Promise<(CartItem & { product: Product })[]> {
    const items = Array.from(this.cartItems.values()).filter(
      item => item.userId === userId
    );
    
    return items.map(item => {
      const product = this.products.get(item.productId);
      if (!product) {
        throw new Error(`Product with id ${item.productId} not found`);
      }
      return { ...item, product };
    });
  }

  async addToCart(cartItem: InsertCartItem): Promise<CartItem> {
    // Check if the item is already in cart
    const existingItem = Array.from(this.cartItems.values()).find(
      item => item.userId === cartItem.userId && item.productId === cartItem.productId
    );
    
    if (existingItem) {
      // Update quantity
      existingItem.quantity += cartItem.quantity;
      return existingItem;
    }
    
    // Add new item
    const id = this.currentCartItemId++;
    const newItem: CartItem = { ...cartItem, id };
    this.cartItems.set(id, newItem);
    return newItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (!item) {
      return undefined;
    }
    
    item.quantity = quantity;
    return item;
  }

  async removeCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(userId: number): Promise<boolean> {
    const itemsToDelete = Array.from(this.cartItems.values())
      .filter(item => item.userId === userId)
      .map(item => item.id);
    
    itemsToDelete.forEach(id => this.cartItems.delete(id));
    return true;
  }

  // Wishlist operations
  async getWishlistItems(userId: number): Promise<(WishlistItem & { product: Product })[]> {
    const items = Array.from(this.wishlistItems.values()).filter(
      item => item.userId === userId
    );
    
    return items.map(item => {
      const product = this.products.get(item.productId);
      if (!product) {
        throw new Error(`Product with id ${item.productId} not found`);
      }
      return { ...item, product };
    });
  }

  async addToWishlist(wishlistItem: InsertWishlistItem): Promise<WishlistItem> {
    // Check if the item is already in wishlist
    const existingItem = Array.from(this.wishlistItems.values()).find(
      item => item.userId === wishlistItem.userId && item.productId === wishlistItem.productId
    );
    
    if (existingItem) {
      return existingItem;
    }
    
    // Add new item
    const id = this.currentWishlistItemId++;
    const newItem: WishlistItem = { ...wishlistItem, id };
    this.wishlistItems.set(id, newItem);
    return newItem;
  }

  async removeWishlistItem(id: number): Promise<boolean> {
    return this.wishlistItems.delete(id);
  }

  // Order operations
  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    const id = this.currentOrderId++;
    const newOrder: Order = { 
      ...order, 
      id, 
      createdAt: new Date() 
    };
    
    this.orders.set(id, newOrder);
    
    // Add order items
    items.forEach(item => {
      const itemId = this.currentOrderItemId++;
      this.orderItems.set(itemId, { ...item, id: itemId, orderId: id });
    });
    
    // If there's a coupon code, update the coupon usage count
    if (order.couponCode) {
      const coupon = Array.from(this.discountCoupons.values()).find(
        c => c.code === order.couponCode
      );
      
      if (coupon) {
        coupon.currentUsageCount = (coupon.currentUsageCount || 0) + 1;
        this.discountCoupons.set(coupon.id, coupon);
      }
    }
    
    return newOrder;
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      order => order.userId === userId
    );
  }

  async getOrderById(id: number): Promise<(Order & { items: (OrderItem & { product: Product })[] }) | undefined> {
    const order = this.orders.get(id);
    if (!order) {
      return undefined;
    }
    
    const orderItems = Array.from(this.orderItems.values())
      .filter(item => item.orderId === id)
      .map(item => {
        const product = this.products.get(item.productId);
        if (!product) {
          throw new Error(`Product with id ${item.productId} not found`);
        }
        return { ...item, product };
      });
    
    return { ...order, items: orderItems };
  }
  
  // Admin methods for order management
  async getAllOrders(): Promise<Order[]> {
    // Return all orders for admin
    return Array.from(this.orders.values());
  }
  
  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    
    if (!order) return undefined;
    
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    
    return updatedOrder;
  }
  
  async verifyOrderPayment(id: number, status: string, notes?: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    
    if (!order) return undefined;
    
    // Add payment verification notes and update status
    const updatedOrder = { 
      ...order, 
      status,
      // Add notes to the order if provided
      ...(notes && { paymentNotes: notes })
    };
    
    this.orders.set(id, updatedOrder);
    
    return updatedOrder;
  }

  // Discount Coupon operations
  async getDiscountCoupon(code: string): Promise<DiscountCoupon | undefined> {
    return Array.from(this.discountCoupons.values()).find(
      coupon => coupon.code === code
    );
  }

  async createDiscountCoupon(coupon: InsertDiscountCoupon): Promise<DiscountCoupon> {
    const id = this.currentDiscountCouponId++;
    const newCoupon: DiscountCoupon = { ...coupon, id, createdAt: new Date() };
    this.discountCoupons.set(id, newCoupon);
    return newCoupon;
  }

  async updateDiscountCoupon(id: number, updates: Partial<InsertDiscountCoupon>): Promise<DiscountCoupon | undefined> {
    const coupon = this.discountCoupons.get(id);
    if (!coupon) {
      return undefined;
    }
    
    const updatedCoupon = { ...coupon, ...updates };
    this.discountCoupons.set(id, updatedCoupon);
    return updatedCoupon;
  }

  async deleteDiscountCoupon(id: number): Promise<boolean> {
    return this.discountCoupons.delete(id);
  }

  async getAllDiscountCoupons(): Promise<DiscountCoupon[]> {
    return Array.from(this.discountCoupons.values());
  }

  async validateCoupon(code: string): Promise<{isValid: boolean; discount?: number; message?: string}> {
    const coupon = await this.getDiscountCoupon(code);
    
    if (!coupon) {
      return { isValid: false, message: "Invalid coupon code" };
    }
    
    if (!coupon.isActive) {
      return { isValid: false, message: "This coupon is no longer active" };
    }
    
    if (coupon.expiryDate && new Date() > new Date(coupon.expiryDate)) {
      return { isValid: false, message: "This coupon has expired" };
    }
    
    if (coupon.currentUsageCount >= coupon.maxUsageCount) {
      return { isValid: false, message: "This coupon has reached its usage limit" };
    }
    
    return { isValid: true, discount: coupon.discountPercentage };
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryByName(name: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      category => category.name === name
    );
  }
}

import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import { eq, and, inArray, gte, lte, desc, asc, sql } from "drizzle-orm";

const { Pool } = pg;

// Database storage implementation using drizzle ORM
export class DbStorage implements IStorage {
  private db: ReturnType<typeof drizzle>;
  private pool: Pool;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is not set");
    }

    this.pool = new Pool({
      connectionString: process.env.DATABASE_URL,
    });

    this.db = drizzle(this.pool);
  }

  async initializeDatabase(): Promise<void> {
    // Check if categories table has data
    const existingCategories = await this.getCategories();
    
    if (existingCategories.length === 0) {
      // Initialize categories
      const categoriesData: InsertCategory[] = [
        {
          name: "Clothes",
          isLocked: false,
          imageUrl: "",
          productCount: 65
        },
        {
          name: "Beauty & Personal Care",
          isLocked: false,
          imageUrl: "",
          productCount: 48
        },
        {
          name: "Section 1",
          isLocked: true,
          message: "No sponsors yet... To sponsor, please mail us.",
          imageUrl: "",
          productCount: 0
        },
        {
          name: "Section 2",
          isLocked: true,
          message: "No sponsors yet... To sponsor, please mail us.",
          imageUrl: "",
          productCount: 0
        },
        {
          name: "Section 3",
          isLocked: true,
          message: "No sponsors yet... To sponsor, please mail us.",
          imageUrl: "",
          productCount: 0
        }
      ];

      // Insert categories into database
      for (const category of categoriesData) {
        await this.db.insert(categories).values(category);
      }

      // Check if products table has data
      const productCount = await this.db.select({ count: sql<number>`count(*)` }).from(products);
      
      if (productCount[0].count === 0) {
        // Initialize sample products
        const productData: InsertProduct[] = [
          {
            name: "Casual Slim Fit T-Shirt",
            description: "A comfortable, slim-fit t-shirt perfect for casual wear.",
            price: 2499, // $24.99
            discountPrice: 2999, // $29.99
            category: "Clothes",
            subcategory: "Men's Fashion",
            imageUrl: "",
            rating: 4,
            reviewCount: 42,
            isNew: false,
            inStock: true,
            brand: "Brand 1",
            size: "M",
            color: "Blue",
            trending: true
          },
          {
            name: "Bohemian Maxi Dress",
            description: "A beautiful bohemian style maxi dress for summer occasions.",
            price: 4999, // $49.99
            category: "Clothes",
            subcategory: "Women's Fashion",
            imageUrl: "",
            rating: 5,
            reviewCount: 78,
            isNew: false,
            inStock: true,
            brand: "Brand 2",
            size: "M",
            color: "Floral",
            trending: true
          },
          {
            name: "Vitamin C Serum",
            description: "High potency vitamin C serum for brighter, healthier skin.",
            price: 3499, // $34.99
            category: "Beauty & Personal Care",
            subcategory: "Skincare",
            imageUrl: "",
            rating: 5,
            reviewCount: 124,
            isNew: true,
            inStock: true,
            brand: "Brand 3",
            trending: true
          },
          {
            name: "Electric Shaver Pro",
            description: "Advanced electric shaver with multiple settings for a clean shave.",
            price: 7999, // $79.99
            discountPrice: 9999, // $99.99
            category: "Beauty & Personal Care",
            subcategory: "Personal Care",
            imageUrl: "",
            rating: 4,
            reviewCount: 56,
            isNew: false,
            inStock: true,
            brand: "Brand 4",
            trending: true
          }
        ];

        // Generate more products to have a good sample
        for (let i = 0; i < 96; i++) {
          const categoryIndex = i % 2;
          const categoryName = categoryIndex === 0 ? "Clothes" : "Beauty & Personal Care";
          const subcategoryIndex = i % 4;
          let subcategory = "";
          
          if (categoryName === "Clothes") {
            subcategory = subcategoryIndex < 2 ? "Men's Fashion" : "Women's Fashion";
          } else {
            subcategory = subcategoryIndex < 2 ? "Skincare" : "Personal Care";
          }
          
          productData.push({
            name: `Product ${i + 5}`,
            description: `Description for product ${i + 5}`,
            price: 1000 + (i * 100), // Price varies from $10 to $100
            category: categoryName,
            subcategory,
            imageUrl: "",
            rating: Math.floor(Math.random() * 5) + 1, // Random rating 1-5
            reviewCount: Math.floor(Math.random() * 100),
            isNew: i % 10 === 0, // Every 10th product is new
            inStock: true,
            brand: `Brand ${(i % 6) + 1}`,
            trending: false
          });
        }

        // Insert products in batches to avoid query size limits
        const batchSize = 20;
        for (let i = 0; i < productData.length; i += batchSize) {
          const batch = productData.slice(i, i + batchSize);
          await this.db.insert(products).values(batch);
        }
      }
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.email, email)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.googleId, googleId)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(user).returning();
    return result[0];
  }

  // Product operations
  async getProducts(category?: string, limit = 20, offset = 0): Promise<Product[]> {
    let query = this.db.select().from(products);
    
    if (category && category !== "all") {
      query = query.where(
        sql`${products.category} = ${category} OR ${products.subcategory} = ${category}`
      );
    }
    
    return await query.limit(limit).offset(offset);
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const result = await this.db.select().from(products).where(eq(products.id, id)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  }

  async getTrendingProducts(limit = 4): Promise<Product[]> {
    return await this.db.select().from(products).where(eq(products.trending, true)).limit(limit);
  }

  async searchProducts(query: string): Promise<Product[]> {
    return await this.db.select().from(products).where(
      sql`${products.name} ILIKE ${`%${query}%`} OR 
          ${products.description} ILIKE ${`%${query}%`} OR
          ${products.category} ILIKE ${`%${query}%`} OR
          ${products.subcategory} ILIKE ${`%${query}%`} OR
          ${products.brand} ILIKE ${`%${query}%`}`
    );
  }

  async filterProducts(filters: ProductFilters): Promise<Product[]> {
    let query = this.db.select().from(products);
    const conditions = [];

    if (filters.category && filters.category !== "all") {
      conditions.push(
        sql`${products.category} = ${filters.category} OR ${products.subcategory} = ${filters.category}`
      );
    }

    if (filters.minPrice !== undefined) {
      conditions.push(gte(products.price, filters.minPrice));
    }

    if (filters.maxPrice !== undefined) {
      conditions.push(lte(products.price, filters.maxPrice));
    }

    if (filters.brand && filters.brand.length > 0) {
      conditions.push(inArray(products.brand, filters.brand));
    }

    if (filters.rating !== undefined) {
      conditions.push(gte(products.rating, filters.rating));
    }

    if (filters.inStock !== undefined) {
      conditions.push(eq(products.inStock, filters.inStock));
    }

    if (filters.size && filters.size.length > 0) {
      conditions.push(inArray(products.size, filters.size));
    }

    if (filters.color && filters.color.length > 0) {
      conditions.push(inArray(products.color, filters.color));
    }

    if (filters.search) {
      conditions.push(
        sql`${products.name} ILIKE ${`%${filters.search}%`} OR 
            ${products.description} ILIKE ${`%${filters.search}%`} OR
            ${products.brand} ILIKE ${`%${filters.search}%`}`
      );
    }

    // Apply all conditions
    if (conditions.length > 0) {
      const [firstCondition, ...otherConditions] = conditions;
      query = query.where(firstCondition);
      
      // Add remaining conditions with AND
      if (otherConditions.length > 0) {
        for (const condition of otherConditions) {
          query = query.where(condition);
        }
      }
    }

    // Apply sorting
    if (filters.sort) {
      switch (filters.sort) {
        case 'price_asc':
          query = query.orderBy(asc(products.price));
          break;
        case 'price_desc':
          query = query.orderBy(desc(products.price));
          break;
        case 'rating':
          query = query.orderBy(desc(products.rating));
          break;
        case 'newest':
          query = query.orderBy(desc(products.isNew));
          break;
      }
    }

    return await query;
  }

  // Cart operations
  async getCartItems(userId: number): Promise<(CartItem & { product: Product })[]> {
    const result = await this.db
      .select()
      .from(cartItems)
      .where(eq(cartItems.userId, userId));

    const itemsWithProducts = [];
    for (const item of result) {
      const product = await this.getProductById(item.productId);
      if (product) {
        itemsWithProducts.push({ ...item, product });
      }
    }

    return itemsWithProducts;
  }

  async addToCart(cartItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists
    const existingItem = await this.db
      .select()
      .from(cartItems)
      .where(
        and(
          eq(cartItems.userId, cartItem.userId),
          eq(cartItems.productId, cartItem.productId)
        )
      )
      .limit(1);

    if (existingItem.length > 0) {
      // Update quantity
      const updated = await this.db
        .update(cartItems)
        .set({ quantity: existingItem[0].quantity + cartItem.quantity })
        .where(eq(cartItems.id, existingItem[0].id))
        .returning();
      return updated[0];
    }

    // Insert new item
    const result = await this.db.insert(cartItems).values(cartItem).returning();
    return result[0];
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const result = await this.db
      .update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, id))
      .returning();
    return result.length > 0 ? result[0] : undefined;
  }

  async removeCartItem(id: number): Promise<boolean> {
    const result = await this.db.delete(cartItems).where(eq(cartItems.id, id));
    return true; // Assuming deletion worked
  }

  async clearCart(userId: number): Promise<boolean> {
    await this.db.delete(cartItems).where(eq(cartItems.userId, userId));
    return true;
  }

  // Wishlist operations
  async getWishlistItems(userId: number): Promise<(WishlistItem & { product: Product })[]> {
    const result = await this.db
      .select()
      .from(wishlistItems)
      .where(eq(wishlistItems.userId, userId));

    const itemsWithProducts = [];
    for (const item of result) {
      const product = await this.getProductById(item.productId);
      if (product) {
        itemsWithProducts.push({ ...item, product });
      }
    }

    return itemsWithProducts;
  }

  async addToWishlist(wishlistItem: InsertWishlistItem): Promise<WishlistItem> {
    // Check if item already exists
    const existingItem = await this.db
      .select()
      .from(wishlistItems)
      .where(
        and(
          eq(wishlistItems.userId, wishlistItem.userId),
          eq(wishlistItems.productId, wishlistItem.productId)
        )
      )
      .limit(1);

    if (existingItem.length > 0) {
      return existingItem[0];
    }

    // Insert new item
    const result = await this.db.insert(wishlistItems).values(wishlistItem).returning();
    return result[0];
  }

  async removeWishlistItem(id: number): Promise<boolean> {
    await this.db.delete(wishlistItems).where(eq(wishlistItems.id, id));
    return true;
  }

  // Order operations
  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    // Start a transaction
    const client = await this.pool.connect();
    
    try {
      await client.query('BEGIN');
      
      // Insert order
      const orderResult = await client.query(
        `INSERT INTO orders (user_id, status, total, shipping_address, payment_method, coupon_code, discount_percentage)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         RETURNING *`,
        [
          order.userId, 
          order.status, 
          order.total, 
          order.shippingAddress, 
          order.paymentMethod, 
          order.couponCode || null, 
          order.discountPercentage || null
        ]
      );
      
      const newOrder = orderResult.rows[0];
      
      // Insert order items
      for (const item of items) {
        await client.query(
          `INSERT INTO order_items (order_id, product_id, quantity, price)
           VALUES ($1, $2, $3, $4)`,
          [newOrder.id, item.productId, item.quantity, item.price]
        );
      }
      
      // Clear the user's cart
      await client.query('DELETE FROM cart_items WHERE user_id = $1', [order.userId]);
      
      // If there's a coupon code, update the coupon usage count
      if (order.couponCode) {
        await client.query(`
          UPDATE discount_coupons 
          SET current_usage_count = COALESCE(current_usage_count, 0) + 1
          WHERE code = $1
        `, [order.couponCode]);
      }
      
      await client.query('COMMIT');
      
      return {
        id: newOrder.id,
        userId: newOrder.user_id,
        status: newOrder.status,
        total: newOrder.total,
        shippingAddress: newOrder.shipping_address,
        paymentMethod: newOrder.payment_method,
        couponCode: newOrder.coupon_code,
        discountPercentage: newOrder.discount_percentage,
        createdAt: newOrder.created_at
      };
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    return await this.db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async getOrderById(id: number): Promise<(Order & { items: (OrderItem & { product: Product })[] }) | undefined> {
    const orderResult = await this.db
      .select()
      .from(orders)
      .where(eq(orders.id, id))
      .limit(1);

    if (orderResult.length === 0) {
      return undefined;
    }

    const order = orderResult[0];
    const orderItemsResult = await this.db
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, id));

    const itemsWithProducts = [];
    for (const item of orderItemsResult) {
      const product = await this.getProductById(item.productId);
      if (product) {
        itemsWithProducts.push({ ...item, product });
      }
    }

    return {
      ...order,
      items: itemsWithProducts
    };
  }
  
  // Admin order management methods
  async getAllOrders(): Promise<Order[]> {
    return await this.db
      .select()
      .from(orders)
      .orderBy(desc(orders.createdAt));
  }
  
  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const result = await this.db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning();
      
    return result.length > 0 ? result[0] : undefined;
  }
  
  async verifyOrderPayment(id: number, status: string, notes?: string): Promise<Order | undefined> {
    // Create updates object
    const updates: any = { status };
    
    // Add payment notes if provided
    if (notes) {
      // Since we don't have a dedicated column for notes, we could store it in a JSON field
      // or create a separate table for order notes. For now, we'll update the order's status
      // which indicates verification status.
      // In a real implementation, you might want to add a notes column or create a separate table
    }
    
    const result = await this.db
      .update(orders)
      .set(updates)
      .where(eq(orders.id, id))
      .returning();
      
    return result.length > 0 ? result[0] : undefined;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await this.db.select().from(categories);
  }

  async getCategoryByName(name: string): Promise<Category | undefined> {
    const result = await this.db
      .select()
      .from(categories)
      .where(eq(categories.name, name))
      .limit(1);
    return result.length > 0 ? result[0] : undefined;
  }

  // Discount Coupon operations
  async getDiscountCoupon(code: string): Promise<DiscountCoupon | undefined> {
    const result = await this.db
      .select()
      .from(discountCoupons)
      .where(eq(discountCoupons.code, code))
      .limit(1);
    return result.length > 0 ? result[0] : undefined;
  }

  async createDiscountCoupon(coupon: InsertDiscountCoupon): Promise<DiscountCoupon> {
    const result = await this.db
      .insert(discountCoupons)
      .values({
        ...coupon,
        createdAt: new Date()
      })
      .returning();
    return result[0];
  }

  async updateDiscountCoupon(id: number, updates: Partial<InsertDiscountCoupon>): Promise<DiscountCoupon | undefined> {
    const result = await this.db
      .update(discountCoupons)
      .set(updates)
      .where(eq(discountCoupons.id, id))
      .returning();
    return result.length > 0 ? result[0] : undefined;
  }

  async deleteDiscountCoupon(id: number): Promise<boolean> {
    await this.db.delete(discountCoupons).where(eq(discountCoupons.id, id));
    return true;
  }

  async getAllDiscountCoupons(): Promise<DiscountCoupon[]> {
    return await this.db.select().from(discountCoupons);
  }

  async validateCoupon(code: string): Promise<{isValid: boolean; discount?: number; message?: string}> {
    const coupon = await this.getDiscountCoupon(code);
    
    if (!coupon) {
      return { isValid: false, message: "Invalid coupon code" };
    }
    
    if (!coupon.isActive) {
      return { isValid: false, message: "This coupon is no longer active" };
    }
    
    if (coupon.expiryDate && new Date() > new Date(coupon.expiryDate)) {
      return { isValid: false, message: "This coupon has expired" };
    }
    
    if (coupon.currentUsageCount >= coupon.maxUsageCount) {
      return { isValid: false, message: "This coupon has reached its usage limit" };
    }
    
    return { isValid: true, discount: coupon.discountPercentage };
  }
}

// Create and export a database storage instance
export const storage = new DbStorage();
