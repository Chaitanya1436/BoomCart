import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertCartItemSchema, 
  insertWishlistItemSchema,
  insertOrderSchema,
  insertOrderItemSchema,
  insertDiscountCouponSchema
} from "@shared/schema";
import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import expressSession from "express-session";
import MemoryStore from "memorystore";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up session
  const SessionStore = MemoryStore(expressSession);
  app.use(expressSession({
    cookie: { maxAge: 86400000 }, // 24 hours
    resave: false,
    saveUninitialized: false,
    secret: process.env.SESSION_SECRET || 'boomcart_secret',
    store: new SessionStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    })
  }));

  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());
  
  // Configure Google OAuth strategy
  const clientID = process.env.GOOGLE_CLIENT_ID || "";
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET || "";
  const callbackURL = process.env.GOOGLE_CALLBACK_URL || "http://localhost:5000/api/auth/google/callback";
  
  passport.use(new GoogleStrategy({
    clientID,
    clientSecret,
    callbackURL
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      // Check if user exists
      let user = await storage.getUserByGoogleId(profile.id);
      
      if (!user) {
        // Create new user
        const email = profile.emails?.[0]?.value || `${profile.id}@gmail.com`;
        const isAdmin = email === 'sayboomcart@gmail.com'; // Set admin for the store owner
        
        user = await storage.createUser({
          username: profile.displayName.replace(/\s+/g, '') || `user${Date.now()}`,
          email: email,
          password: "", // Password not needed for OAuth
          googleId: profile.id,
          displayName: profile.displayName,
          avatarUrl: profile.photos?.[0]?.value,
          isAdmin: isAdmin
        });
      }
      
      return done(null, user);
    } catch (error) {
      return done(error);
    }
  }));
  
  // Serialize and deserialize user
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });
  
  // Auth routes
  app.get('/api/auth/google',
    passport.authenticate('google', { scope: ['profile', 'email'] })
  );
  
  app.get('/api/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/' }),
    (req, res) => {
      res.redirect('/');
    }
  );
  
  app.get('/api/auth/logout', (req, res) => {
    req.logout(() => {
      res.redirect('/');
    });
  });
  
  app.get('/api/auth/status', (req, res) => {
    if (req.isAuthenticated()) {
      res.json({ isAuthenticated: true, user: req.user });
    } else {
      res.json({ isAuthenticated: false });
    }
  });
  
  // Middleware to check authentication
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ error: 'Unauthorized' });
  };
  
  // Category routes
  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch categories' });
    }
  });
  
  // Product routes
  app.get('/api/products', async (req, res) => {
    try {
      const { category, limit, offset, sort, minPrice, maxPrice, rating, brand } = req.query;
      
      const filters: any = {};
      
      if (category) filters.category = category as string;
      if (minPrice) filters.minPrice = parseInt(minPrice as string);
      if (maxPrice) filters.maxPrice = parseInt(maxPrice as string);
      if (rating) filters.rating = parseInt(rating as string);
      if (sort) filters.sort = sort as 'price_asc' | 'price_desc' | 'newest' | 'rating';
      if (brand) {
        const brands = Array.isArray(brand) ? brand : [brand];
        filters.brand = brands as string[];
      }
      
      const products = await storage.filterProducts(filters);
      
      const limitVal = limit ? parseInt(limit as string) : 20;
      const offsetVal = offset ? parseInt(offset as string) : 0;
      
      res.json({
        products: products.slice(offsetVal, offsetVal + limitVal),
        total: products.length
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch products' });
    }
  });
  
  app.get('/api/products/trending', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 4;
      const products = await storage.getTrendingProducts(limit);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch trending products' });
    }
  });
  
  app.get('/api/products/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProductById(id);
      
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch product' });
    }
  });
  
  app.get('/api/products/search/:query', async (req, res) => {
    try {
      const query = req.params.query;
      const products = await storage.searchProducts(query);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: 'Failed to search products' });
    }
  });

  // Cart routes
  app.get('/api/cart', isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const cartItems = await storage.getCartItems(userId);
      res.json(cartItems);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch cart items' });
    }
  });
  
  app.post('/api/cart', isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const schema = insertCartItemSchema.extend({
        productId: z.number(),
        quantity: z.number().min(1)
      });
      
      const validatedData = schema.parse({ ...req.body, userId });
      const cartItem = await storage.addToCart(validatedData);
      res.status(201).json(cartItem);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Invalid data' });
    }
  });
  
  app.put('/api/cart/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const quantity = req.body.quantity;
      
      if (typeof quantity !== 'number' || quantity < 1) {
        return res.status(400).json({ error: 'Invalid quantity' });
      }
      
      const updatedItem = await storage.updateCartItem(id, quantity);
      
      if (!updatedItem) {
        return res.status(404).json({ error: 'Cart item not found' });
      }
      
      res.json(updatedItem);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update cart item' });
    }
  });
  
  app.delete('/api/cart/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.removeCartItem(id);
      
      if (!success) {
        return res.status(404).json({ error: 'Cart item not found' });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to remove cart item' });
    }
  });
  
  app.delete('/api/cart', isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      await storage.clearCart(userId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to clear cart' });
    }
  });
  
  // Wishlist routes
  app.get('/api/wishlist', isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const wishlistItems = await storage.getWishlistItems(userId);
      res.json(wishlistItems);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch wishlist items' });
    }
  });
  
  app.post('/api/wishlist', isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const schema = insertWishlistItemSchema.extend({
        productId: z.number()
      });
      
      const validatedData = schema.parse({ ...req.body, userId });
      const wishlistItem = await storage.addToWishlist(validatedData);
      res.status(201).json(wishlistItem);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Invalid data' });
    }
  });
  
  app.delete('/api/wishlist/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.removeWishlistItem(id);
      
      if (!success) {
        return res.status(404).json({ error: 'Wishlist item not found' });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to remove wishlist item' });
    }
  });
  
  // Order routes
  app.post('/api/orders', isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      
      // Validate order data
      const orderSchema = insertOrderSchema.extend({
        total: z.number().min(1),
        shippingAddress: z.string().min(1),
        paymentMethod: z.string().min(1),
        couponCode: z.string().optional(),
        discountPercentage: z.number().optional()
      });
      
      const orderData = orderSchema.parse({ ...req.body, userId });
      
      // Validate items data
      const itemsSchema = z.array(
        insertOrderItemSchema.extend({
          productId: z.number(),
          quantity: z.number().min(1),
          price: z.number().min(1)
        })
      );
      
      const itemsData = itemsSchema.parse(req.body.items);
      
      // If there's a coupon code, validate it
      if (orderData.couponCode) {
        const validation = await storage.validateCoupon(orderData.couponCode);
        
        if (!validation.isValid) {
          return res.status(400).json({ error: validation.message || 'Invalid coupon' });
        }
        
        // Update the discount percentage in order data
        orderData.discountPercentage = validation.discount;
      }
      
      // Create order
      const order = await storage.createOrder(orderData, itemsData);
      
      // Clear cart after successful order
      await storage.clearCart(userId);
      
      res.status(201).json(order);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Invalid data' });
    }
  });
  
  app.get('/api/orders', isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const orders = await storage.getOrdersByUser(userId);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch orders' });
    }
  });
  
  app.get('/api/orders/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const order = await storage.getOrderById(id);
      
      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }
      
      if ((req.user as any).id !== order.userId) {
        return res.status(403).json({ error: 'Forbidden' });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch order' });
    }
  });

  // Middleware to check if user is admin
  const isAdmin = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated() && (req.user as any).isAdmin) {
      return next();
    }
    res.status(403).json({ error: 'Forbidden: Admin access required' });
  };

  // Discount Coupon routes - Admin only
  app.get('/api/discount-coupons', isAdmin, async (req, res) => {
    try {
      const coupons = await storage.getAllDiscountCoupons();
      res.json(coupons);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch discount coupons' });
    }
  });

  app.post('/api/discount-coupons', isAdmin, async (req, res) => {
    try {
      const schema = insertDiscountCouponSchema.extend({
        code: z.string().min(3),
        influencerName: z.string().min(1),
        discountPercentage: z.number().min(1).max(100),
        maxUsageCount: z.number().min(1),
        isActive: z.boolean().default(true),
        currentUsageCount: z.number().default(0),
        expiryDate: z.date().optional()
      });
      
      const validatedData = schema.parse(req.body);
      const coupon = await storage.createDiscountCoupon(validatedData);
      res.status(201).json(coupon);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Invalid data' });
    }
  });

  app.get('/api/discount-coupons/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      // Find coupon by ID from the array of all coupons
      const coupons = await storage.getAllDiscountCoupons();
      const coupon = coupons.find(c => c.id === id);
      
      if (!coupon) {
        return res.status(404).json({ error: 'Discount coupon not found' });
      }
      
      res.json(coupon);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch discount coupon' });
    }
  });

  app.put('/api/discount-coupons/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const schema = z.object({
        code: z.string().min(3).optional(),
        influencerName: z.string().min(1).optional(),
        discountPercentage: z.number().min(1).max(100).optional(),
        maxUsageCount: z.number().min(1).optional(),
        isActive: z.boolean().optional(),
        currentUsageCount: z.number().min(0).optional(),
        expiryDate: z.date().optional().nullable()
      });
      
      const validatedData = schema.parse(req.body);
      const coupon = await storage.updateDiscountCoupon(id, validatedData);
      
      if (!coupon) {
        return res.status(404).json({ error: 'Discount coupon not found' });
      }
      
      res.json(coupon);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Invalid data' });
    }
  });

  app.delete('/api/discount-coupons/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteDiscountCoupon(id);
      
      if (!success) {
        return res.status(404).json({ error: 'Discount coupon not found' });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete discount coupon' });
    }
  });

  // Validate coupon route - For checkout process
  app.post('/api/validate-coupon', isAuthenticated, async (req, res) => {
    try {
      const { code } = req.body;
      
      if (!code || typeof code !== 'string') {
        return res.status(400).json({ error: 'Coupon code is required' });
      }
      
      const result = await storage.validateCoupon(code);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to validate coupon' });
    }
  });
  
  // Admin routes - Order management
  app.get('/api/admin/orders', isAdmin, async (req, res) => {
    try {
      // Get all orders (admin can see all orders)
      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch orders' });
    }
  });

  app.get('/api/admin/orders/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const order = await storage.getOrderById(id);
      
      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch order' });
    }
  });

  app.put('/api/admin/orders/:id/status', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || typeof status !== 'string') {
        return res.status(400).json({ error: 'Status is required' });
      }
      
      // Valid statuses
      const validStatuses = [
        'pending_verification', 
        'payment_verified',
        'processing', 
        'shipped', 
        'delivered', 
        'cancelled'
      ];
      
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ 
          error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` 
        });
      }
      
      const updatedOrder = await storage.updateOrderStatus(id, status);
      
      if (!updatedOrder) {
        return res.status(404).json({ error: 'Order not found' });
      }
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update order status' });
    }
  });

  app.put('/api/admin/orders/:id/verify-payment', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { isVerified, notes } = req.body;
      
      if (typeof isVerified !== 'boolean') {
        return res.status(400).json({ error: 'isVerified boolean is required' });
      }
      
      // Update order status based on verification
      const status = isVerified ? 'payment_verified' : 'payment_failed';
      const updatedOrder = await storage.verifyOrderPayment(id, status, notes);
      
      if (!updatedOrder) {
        return res.status(404).json({ error: 'Order not found' });
      }
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ error: 'Failed to verify payment' });
    }
  });

  // Email notification for orders (would use a real email service in production)
  app.post('/api/notify/order', isAuthenticated, async (req, res) => {
    try {
      const { email, orderData } = req.body;
      
      if (!email || !orderData) {
        return res.status(400).json({ error: 'Email and order data are required' });
      }
      
      // In a real implementation, you would send an email here
      // For now, we'll just log it to the console
      console.log(`[ORDER NOTIFICATION] New order notification sent to ${email}`);
      console.log(`[ORDER NOTIFICATION] Order details: Transaction ID: ${orderData.transactionId}, Amount: ₹${orderData.total}`);
      
      res.json({ success: true, message: 'Notification sent' });
    } catch (error) {
      console.error('Failed to send notification:', error);
      res.status(500).json({ error: 'Failed to send notification' });
    }
  });
  
  // Admin routes for discount coupons
  app.get('/api/admin/coupons', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const coupons = await storage.getAllDiscountCoupons();
      res.json(coupons);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.post('/api/admin/coupons', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const schema = insertDiscountCouponSchema.extend({
        code: z.string().min(3),
        influencerName: z.string().min(1),
        discountPercentage: z.number().min(1).max(100),
        maxUsageCount: z.number().min(1),
        isActive: z.boolean().default(true),
        currentUsageCount: z.number().default(0),
        expiryDate: z.string().optional().nullable()
      });
      
      const validatedData = schema.parse(req.body);
      // Convert string date to Date object if present
      const couponData = {
        ...validatedData,
        expiryDate: validatedData.expiryDate ? new Date(validatedData.expiryDate) : null
      };
      
      const coupon = await storage.createDiscountCoupon(couponData);
      res.status(201).json(coupon);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });
  
  app.put('/api/admin/coupons/:id', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const couponId = parseInt(req.params.id, 10);
      const schema = z.object({
        code: z.string().min(3).optional(),
        influencerName: z.string().min(1).optional(),
        discountPercentage: z.number().min(1).max(100).optional(),
        maxUsageCount: z.number().min(1).optional(),
        isActive: z.boolean().optional(),
        expiryDate: z.string().optional().nullable()
      });
      
      const validatedData = schema.parse(req.body);
      // Convert string date to Date object if present
      const updates = {
        ...validatedData,
        expiryDate: validatedData.expiryDate ? new Date(validatedData.expiryDate) : null
      };
      
      const coupon = await storage.updateDiscountCoupon(couponId, updates);
      
      if (!coupon) {
        return res.status(404).json({ error: 'Coupon not found' });
      }
      
      res.json(coupon);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.put('/api/admin/coupons/:id/toggle-status', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const couponId = parseInt(req.params.id, 10);
      const { isActive } = req.body;
      
      if (typeof isActive !== 'boolean') {
        return res.status(400).json({ error: 'isActive boolean is required' });
      }
      
      const coupon = await storage.updateDiscountCoupon(couponId, { isActive });
      
      if (!coupon) {
        return res.status(404).json({ error: 'Coupon not found' });
      }
      
      res.json(coupon);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.delete('/api/admin/coupons/:id', isAuthenticated, isAdmin, async (req, res) => {
    try {
      const couponId = parseInt(req.params.id, 10);
      const success = await storage.deleteDiscountCoupon(couponId);
      
      if (!success) {
        return res.status(404).json({ error: 'Coupon not found' });
      }
      
      res.status(204).end();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
